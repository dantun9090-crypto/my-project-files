import { ReactNode, useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, X, Plus, Minus, Trash2, Menu, User as UserIcon, Mail, MapPin, CreditCard, Package, CheckCircle2, ChevronLeft, ShieldAlert, Check } from 'lucide-react';
import { auth, registerUser, loginUser, logoutUser, saveOrder, Timestamp } from '@/lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { mockGetCurrentUser, mockLogoutUser } from '@/lib/mockAuth';

interface LayoutProps {
  children: ReactNode;
}

interface CartItem {
  id: number;
  name: string;
  dosage: string;
  price: string;
  quantity: number;
}

interface CheckoutForm {
  firstName: string;
  lastName: string;
  email: string | null;
  phone: string;
  address: string;
  city: string;
  postcode: string;
  paymentMethod: 'card' | 'paypal' | 'bank';
  createAccount: boolean;
  password: string;
}

const navLinks = [
  { name: 'Home', href: '/', hash: false },
  { name: 'Products', href: '/products', hash: false },
  { name: 'About', href: '/#about', hash: true },
  { name: 'FAQ', href: '/#faq', hash: true },
  { name: 'Contact', href: '/#contact', hash: true },
];

export function Layout({ children }: LayoutProps) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [checkoutForm, setCheckoutForm] = useState<CheckoutForm>({
    firstName: '',
    lastName: '',
    email: null,
    phone: '',
    address: '',
    city: '',
    postcode: '',
    paymentMethod: 'card',
    createAccount: false,
    password: '',
  });
  const [, setAgeVerified] = useState(() => {
    return sessionStorage.getItem('ageVerified') === 'true';
  });
  const [showAgeGate, setShowAgeGate] = useState(() => {
    return sessionStorage.getItem('ageVerified') !== 'true';
  });
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [, setAuthLoading] = useState(true);
  const [_loginError, setLoginError] = useState('');
  const [_isRegistering, setIsRegistering] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const savedCart = localStorage.getItem('php_cart');
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }

    const handleCartUpdate = () => {
      const updatedCart = localStorage.getItem('php_cart');
      if (updatedCart) {
        setCart(JSON.parse(updatedCart));
      }
    };

    window.addEventListener('cartUpdated', handleCartUpdate);
    return () => window.removeEventListener('cartUpdated', handleCartUpdate);
  }, []);

  // Firebase auth state listener (with mock auth fallback)
  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Try Firebase first
        const unsubscribe = onAuthStateChanged(auth, (user) => {
          if (user) {
            setFirebaseUser(user);
            if (user.email) {
              setCheckoutForm(prev => ({
                ...prev,
                email: user.email
              }));
            }
          } else {
            // Fall back to mock auth
            const mockUser = mockGetCurrentUser();
            if (mockUser) {
              setFirebaseUser({
                uid: mockUser.uid,
                email: mockUser.email,
                displayName: `${mockUser.firstName} ${mockUser.lastName}`,
              } as User);
              setCheckoutForm(prev => ({
                ...prev,
                email: mockUser.email
              }));
            }
          }
          setAuthLoading(false);
        });
        return () => unsubscribe();
      } catch (err) {
        // Firebase not configured, use mock auth
        const mockUser = mockGetCurrentUser();
        if (mockUser) {
          setFirebaseUser({
            uid: mockUser.uid,
            email: mockUser.email,
            displayName: `${mockUser.firstName} ${mockUser.lastName}`,
          } as User);
          setCheckoutForm(prev => ({
            ...prev,
            email: mockUser.email
          }));
        }
        setAuthLoading(false);
      }
    };
    checkAuth();
  }, []);

  const updateQuantity = (id: number, delta: number) => {
    const updatedCart = cart.map(item => {
      if (item.id === id) {
        const newQuantity = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQuantity };
      }
      return item;
    });
    setCart(updatedCart);
    localStorage.setItem('php_cart', JSON.stringify(updatedCart));
  };

  const removeItem = (id: number) => {
    const updatedCart = cart.filter(item => item.id !== id);
    setCart(updatedCart);
    localStorage.setItem('php_cart', JSON.stringify(updatedCart));
    window.dispatchEvent(new Event('cartUpdated'));
  };

  const getTotalItems = () => cart.reduce((sum, item) => sum + item.quantity, 0);
  
  const getTotalPrice = () => {
    return cart.reduce((sum, item) => {
      const price = parseFloat(item.price.replace('£', ''));
      return sum + price * item.quantity;
    }, 0).toFixed(2);
  };

  const handleAgeVerify = () => {
    sessionStorage.setItem('ageVerified', 'true');
    setAgeVerified(true);
    setShowAgeGate(false);
  };

  const handleAgeDeny = () => {
    window.location.href = 'https://www.google.com';
  };

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    
    // Validate form
    if (!checkoutForm.firstName || !checkoutForm.lastName || !checkoutForm.email || !checkoutForm.address) {
      setLoginError('Please fill in all required fields');
      return;
    }
    
    // Validate password if creating account
    if (checkoutForm.createAccount && (!checkoutForm.password || checkoutForm.password.length < 8)) {
      setLoginError('Please create a password with at least 8 characters');
      return;
    }
    
    const total = getTotalPrice();
    const orderId = 'PHP-' + Date.now().toString(36).toUpperCase();
    
    try {
      let userId = firebaseUser?.uid;
      
      // Create Firebase account if requested
      if (checkoutForm.createAccount && !firebaseUser) {
        try {
          const newUser = await registerUser(
            checkoutForm.email,
            checkoutForm.password,
            checkoutForm.firstName,
            checkoutForm.lastName
          );
          userId = newUser.uid;
        } catch (error: any) {
          if (error.code === 'auth/email-already-in-use') {
            setLoginError('Email already registered. Please login or use a different email.');
          } else {
            setLoginError('Failed to create account: ' + error.message);
          }
          return;
        }
      }
      
      // Prepare order data for Firestore
      const orderData = {
        orderId: orderId,
        customer: {
          firstName: checkoutForm.firstName,
          lastName: checkoutForm.lastName,
          email: checkoutForm.email,
          phone: checkoutForm.phone,
          address: checkoutForm.address,
          city: checkoutForm.city,
          postcode: checkoutForm.postcode,
        },
        items: cart,
        total: total,
        paymentMethod: checkoutForm.paymentMethod,
        status: 'pending_payment',
        createdAt: Timestamp.now()
      };
      
      // Save order to Firestore if user is logged in
      if (userId) {
        await saveOrder(userId, orderData);
      }
      
      // Keep local copy for reference
      localStorage.setItem('php_pending_order', JSON.stringify({
        ...orderData,
        createdAt: new Date().toISOString()
      }));
      
      // Redirect to payment
      if (checkoutForm.paymentMethod === 'paypal') {
        const paypalUrl = `https://paypal.me/prohealthpeptides/${total}`;
        window.open(paypalUrl, '_blank');
        setOrderPlaced(true);
      } else if (checkoutForm.paymentMethod === 'card') {
        // Stripe integration - redirect to Stripe Checkout
        // For production, create a Payment Link in Stripe Dashboard
        const stripeCheckoutUrl = `https://checkout.stripe.com/pay?amount=${parseFloat(total) * 100}&currency=gbp&description=${encodeURIComponent('Pro Health Peptides Order ' + orderId)}`;
        window.open(stripeCheckoutUrl, '_blank');
        setOrderPlaced(true);
      } else if (checkoutForm.paymentMethod === 'bank') {
        setOrderPlaced(true);
      }
      
      // Clear cart
      setTimeout(() => {
        setCart([]);
        localStorage.setItem('php_cart', '[]');
        window.dispatchEvent(new Event('cartUpdated'));
      }, 5000);
      
    } catch (error: any) {
      setLoginError('Checkout failed: ' + error.message);
    }
  };

  const closeCart = () => {
    setIsCartOpen(false);
    setShowCheckout(false);
    setOrderPlaced(false);
    setLoginError('');
  };

  const handleLogin = async (email: string, password: string) => {
    setLoginError('');
    setIsRegistering(false);
    try {
      await loginUser(email, password);
      // Login successful - user state will update via onAuthStateChanged
    } catch (error: any) {
      if (error.code === 'auth/user-not-found') {
        setLoginError('No account found with this email.');
      } else if (error.code === 'auth/wrong-password') {
        setLoginError('Incorrect password.');
      } else {
        setLoginError('Login failed: ' + error.message);
      }
    }
  };
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  handleLogin;

  const handleLogout = async () => {
    try {
      await logoutUser();
    } catch (firebaseErr) {
      // Firebase not configured, use mock logout
      mockLogoutUser();
    }
    setFirebaseUser(null);
  };
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  handleLogout;

  const isActive = (href: string) => {
    if (href === '/') return location.pathname === '/';
    return location.pathname === href;
  };

  const handleNavClick = (href: string, isHash: boolean) => {
    if (isHash) {
      if (location.pathname === '/') {
        const element = document.querySelector(href.replace('/', ''));
        element?.scrollIntoView({ behavior: 'smooth' });
      } else {
        window.location.href = href;
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Age Verification Gate */}
      {showAgeGate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-gray-900 to-purple-900/20" />
          <div className="relative w-full max-w-md mx-4">
            <div className="bg-gray-800/90 backdrop-blur-xl border border-white/10 rounded-2xl p-8 shadow-2xl">
              {/* Icon */}
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                  <ShieldAlert className="w-8 h-8 text-white" />
                </div>
              </div>

              {/* Title */}
              <h2 className="text-2xl font-bold text-white text-center mb-2">
                Age Verification Required
              </h2>

              {/* Description */}
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 mb-6">
                <p className="text-amber-200 text-sm text-center">
                  This website contains products intended for laboratory research use only.
                  You must be <span className="font-bold text-amber-400">18 years or older</span> to enter.
                </p>
              </div>

              {/* Age Buttons */}
              <div className="space-y-3">
                <button
                  onClick={handleAgeVerify}
                  className="w-full py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-xl transition-all flex items-center justify-center gap-2 group"
                >
                  <Check className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  I am 18 years or older
                </button>
                <button
                  onClick={handleAgeDeny}
                  className="w-full py-3 bg-gray-700/50 hover:bg-gray-700 text-gray-400 hover:text-white font-medium rounded-xl transition-all border border-white/5"
                >
                  I am under 18 - Exit Site
                </button>
              </div>

              {/* Additional Info */}
              <div className="mt-6 pt-4 border-t border-white/10">
                <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
                  <img
                    src="https://cdn.wegic.ai/assets/onepage/agent/images/1773234372536_edited.png"
                    alt="Pro Health Peptides"
                    className="w-5 h-5 object-contain opacity-60"
                  />
                  <span>Pro Health Peptides | Research Use Only</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-40 bg-gray-900/95 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3">
              <img
                src="https://cdn.wegic.ai/assets/onepage/agent/images/1773234372536_edited.png"
                alt="Pro Health Peptides"
                className="w-10 h-10 object-contain"
              />
              <span className="font-bold text-white text-sm sm:text-lg whitespace-nowrap">Pro Health Peptides</span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              {navLinks.map((link) =>
                link.hash ? (
                  <button
                    key={link.name}
                    onClick={() => handleNavClick(link.href, link.hash)}
                    className="text-sm font-medium text-gray-400 hover:text-white transition-colors bg-transparent border-none cursor-pointer"
      >

                    {link.name}
                  </button>
                ) : (
                  <Link
                    key={link.name}
                    to={link.href}
                    className={`text-sm font-medium transition-colors ${
                      isActive(link.href) ? 'text-blue-400' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    {link.name}
                  </Link>
                )
              )}
            </div>

            {/* Cart & Account Buttons */}
            <div className="flex items-center gap-3">

              {/* My Account Link */}
              <Link
                to="/account"
                className="hidden md:flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
              >
                <UserIcon className="w-5 h-5" />
                <span className="text-sm font-medium">My Account</span>
              </Link>

              <div className="w-px h-6 bg-white/10 hidden md:block" />

              {/* Login Link */}
              <Link
                to="/login"
                className="hidden md:flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
              >
                <span className="text-sm font-medium">Login</span>
              </Link>

              <div className="w-px h-6 bg-white/10 hidden md:block" />

              {/* Desktop Cart Icon */}
              <button
                onClick={() => setIsCartOpen(true)}
                className="hidden md:flex relative p-2 text-gray-400 hover:text-white transition-colors"
              >
                <ShoppingCart className="w-6 h-6" />
                {getTotalItems() > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-blue-600 text-white text-xs rounded-full flex items-center justify-center font-bold">
                    {getTotalItems()}
                  </span>
                )}
              </button>

              {/* Mobile Cart Icon */}
              <button
                onClick={() => setIsCartOpen(true)}
                className="md:hidden relative p-2 text-gray-400 hover:text-white transition-colors"
              >
                <ShoppingCart className="w-6 h-6" />
                {getTotalItems() > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-blue-600 text-white text-xs rounded-full flex items-center justify-center font-bold">
                    {getTotalItems()}
                  </span>
                )}
              </button>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-2 text-gray-400 hover:text-white"
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden py-4 border-t border-white/10">
              <div className="flex flex-col gap-4">
                {navLinks.map((link) =>
                  link.hash ? (
                    <button
                      key={link.name}
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        handleNavClick(link.href, link.hash);
                      }}
                      className="text-sm font-medium text-gray-400 text-left bg-transparent border-none cursor-pointer"
                    >
                      {link.name}
                    </button>
                  ) : (
                    <Link
                      key={link.name}
                      to={link.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={`text-sm font-medium ${
                        isActive(link.href) ? 'text-blue-400' : 'text-gray-400'
                      }`}
                    >
                      {link.name}
                    </Link>
                  )
                )}
                
                {/* Mobile Login Link */}
                <Link
                  to="/login"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-sm font-medium text-gray-400"
                >
                  Login
                </Link>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Cart Drawer */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={closeCart}
          />

          <div 
            className="relative w-full max-w-lg bg-gray-900 shadow-2xl border-l border-white/10 overflow-hidden"
            style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-white/10 flex-shrink-0" style={{ flexShrink: 0 }}>
              {showCheckout ? (
                <button
                  onClick={() => setShowCheckout(false)}
                  className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" />
                  <span className="font-medium">Back to Cart</span>
                </button>
              ) : (
                <h2 className="text-xl font-semibold text-white">Shopping Cart ({getTotalItems()})</h2>
              )}
              <button
                onClick={closeCart}
                className="p-2 text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cart Items or Checkout Form - Scrollable */}
            <div 
              className="checkout-scroll-container flex-1 overflow-y-auto"
              style={{ 
                flex: '1 1 auto', 
                overflowY: 'auto',
                WebkitOverflowScrolling: 'touch',
                overscrollBehavior: 'contain'
              }}
            >
              {orderPlaced ? (
                /* Order Success */
                <div className="p-6">
                  <div className="flex flex-col items-center justify-center text-center mb-6">
                    <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mb-4">
                      <CheckCircle2 className="w-10 h-10 text-green-400" />
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-2">Order Placed!</h3>
                    <p className="text-gray-400 mb-2">Thank you for your order.</p>
                    {(() => {
                      const orderData = JSON.parse(localStorage.getItem('php_pending_order') || '{}');
                      return orderData.orderId && (
                        <p className="text-sm text-blue-400 font-mono">Order ID: {orderData.orderId}</p>
                      );
                    })()}
                  </div>

                  {/* Account Created Notice */}
                  {checkoutForm.createAccount && (
                    <div className="bg-blue-500/10 rounded-xl p-4 border border-blue-500/20 mb-4">
                      <div className="flex items-center gap-2 mb-2">
                        <UserIcon className="w-5 h-5 text-blue-400" />
                        <h4 className="font-semibold text-white">Account Created!</h4>
                      </div>
                      <p className="text-sm text-gray-400">Your account has been created with email:</p>
                      <p className="text-sm text-blue-400 font-medium mt-1">{checkoutForm.email}</p>
                      <p className="text-xs text-gray-500 mt-2">Login details have been saved for future orders.</p>
                    </div>
                  )}

                  {/* Payment Instructions */}
                  <div className="bg-gray-800/50 rounded-xl p-4 border border-white/10 mb-6">
                    <h4 className="font-semibold text-white mb-3 flex items-center gap-2">
                      <CreditCard className="w-5 h-5 text-blue-400" />
                      Payment Instructions
                    </h4>

                    {checkoutForm.paymentMethod === 'bank' && (
                      <div className="space-y-3 text-sm">
                        <div className="bg-amber-500/10 rounded-lg p-3 border border-amber-500/20">
                          <p className="text-amber-400 text-xs">⚠️ Order ships after payment confirmation</p>
                        </div>
                        <p className="text-gray-400">Please transfer to:</p>
                        <div className="bg-gray-900 rounded-lg p-3 font-mono text-xs">
                          <p className="text-white">Account Name: Pro Health Peptides</p>
                          <p className="text-white">Sort Code: XX-XX-XX</p>
                          <p className="text-white">Account: XXXXXXXX</p>
                          <p className="text-gray-500 mt-2">Reference: {checkoutForm.lastName}-{Date.now().toString().slice(-4)}</p>
                        </div>
                        <p className="text-xs text-gray-500">Email confirmation sent to {checkoutForm.email}</p>
                      </div>
                    )}

                    {checkoutForm.paymentMethod === 'paypal' && (
                      <div className="space-y-3 text-sm">
                        <div className="bg-blue-500/10 rounded-lg p-3 border border-blue-500/20">
                          <p className="text-blue-400">✓ PayPal payment window opened</p>
                        </div>
                        <p className="text-gray-400">If payment window didn't open:</p>
                        <a
                          href={`https://paypal.me/prohealthpeptides/${getTotalPrice()}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-block bg-[#0070BA] text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-[#003087] transition-colors"
                        >
                          Pay with PayPal
                        </a>
                        <p className="text-xs text-gray-500">Email confirmation sent to {checkoutForm.email}</p>
                      </div>
                    )}

                    {checkoutForm.paymentMethod === 'card' && (
                      <div className="space-y-3 text-sm">
                        <div className="bg-purple-500/10 rounded-lg p-3 border border-purple-500/20">
                          <p className="text-purple-400">✓ Stripe checkout window opened</p>
                        </div>
                        <p className="text-gray-400">Complete your payment securely with Stripe. We accept all major cards.</p>
                        <div className="flex gap-2 text-xl mt-2">
                          <span>💳</span><span>🇬🇧</span><span>🔒</span>
                        </div>
                        <p className="text-xs text-gray-500 mt-2">Order confirmation sent to {checkoutForm.email}</p>
                      </div>
                    )}
                  </div>

                </div>
              ) : showCheckout ? (
                /* Checkout Form */
                <div className="p-6 space-y-6">
                  {/* Returning Customer Login */}
                  <div className="bg-gray-800/50 rounded-xl p-4 border border-white/10">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-green-600 flex items-center justify-center">
                        <UserIcon className="w-5 h-5 text-white" />
                      </div>
                      <div className="text-left flex-1">
                        <p className="font-semibold text-white">Returning Customer?</p>
                        <p className="text-sm text-gray-400">Login for faster checkout</p>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <input
                        type="email"
                        placeholder="Email address"
                        className="w-full bg-gray-900 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-green-500"
                      />
                      <input
                        type="password"
                        placeholder="Password"
                        className="w-full bg-gray-900 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-green-500"
                      />
                      <button
                        type="button"
                        onClick={() => alert('Login functionality requires backend. Account data is stored locally for demo purposes.')}
                        className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-xl font-medium transition-colors"
                      >
                        Login
                      </button>
                    </div>
                    <div className="mt-3 pt-3 border-t border-white/10">
                      <button className="text-sm text-gray-400 hover:text-white transition-colors">
                        Forgot password?
                      </button>
                    </div>
                  </div>

                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-white/10" />
                    </div>
                    <div className="relative flex justify-center text-sm">
                      <span className="px-2 bg-gray-900 text-gray-500">Or checkout as guest</span>
                    </div>
                  </div>

                  {/* Create Account Toggle */}
                  <div className="bg-gray-800/50 rounded-xl p-4 border border-white/10">
                    <button
                      onClick={() => setCheckoutForm({ ...checkoutForm, createAccount: !checkoutForm.createAccount })}
                      className="flex items-center gap-3 w-full"
                    >
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${checkoutForm.createAccount ? 'bg-blue-600' : 'bg-gray-700'}`}>
                        <UserIcon className="w-5 h-5 text-white" />
                      </div>
                      <div className="text-left flex-1">
                        <p className="font-semibold text-white">Create Account</p>
                        <p className="text-sm text-gray-400">Save your details for faster checkout</p>
                      </div>
                      <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${checkoutForm.createAccount ? 'bg-blue-600 border-blue-600' : 'border-gray-600'}`}>
                        {checkoutForm.createAccount && <CheckCircle2 className="w-3 h-3 text-white" />}
                      </div>
                    </button>
                    
                    {checkoutForm.createAccount && (
                      <div className="mt-4 pt-4 border-t border-white/10 space-y-4">
                        <div className="bg-blue-500/10 rounded-lg p-3 border border-blue-500/20">
                          <p className="text-blue-400 text-xs">
                            Account will be created after order completion. Login details sent via email.
                          </p>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-400 mb-2">Create Password *</label>
                          <input
                            type="password"
                            value={checkoutForm.password}
                            onChange={(e) => setCheckoutForm({ ...checkoutForm, password: e.target.value })}
                            placeholder="Min 8 characters"
                            minLength={8}
                            className="w-full bg-gray-900 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                            required={checkoutForm.createAccount}
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-400 mb-2">Confirm Password *</label>
                          <input
                            type="password"
                            placeholder="Repeat password"
                            className="w-full bg-gray-900 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                            required={checkoutForm.createAccount}
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Personal Information */}
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <UserIcon className="w-5 h-5 text-blue-400" />
                      Personal Information
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-400 mb-2">First Name</label>
                        <input
                          type="text"
                          value={checkoutForm.firstName}
                          onChange={(e) => setCheckoutForm({ ...checkoutForm, firstName: e.target.value })}
                          placeholder="John"
                          className="w-full bg-gray-800/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-400 mb-2">Last Name</label>
                        <input
                          type="text"
                          value={checkoutForm.lastName}
                          onChange={(e) => setCheckoutForm({ ...checkoutForm, lastName: e.target.value })}
                          placeholder="Doe"
                          className="w-full bg-gray-800/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                          required
                        />
                      </div>
                    </div>
                    <div className="mt-4">
                      <label className="block text-sm font-medium text-gray-400 mb-2">Email</label>
                      <div className="relative">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                        <input
                          type="email"
                          value={checkoutForm.email || ''}
                          onChange={(e) => setCheckoutForm({ ...checkoutForm, email: e.target.value })}
                          placeholder="john@example.com"
                          className="w-full bg-gray-800/50 border border-white/10 rounded-lg pl-12 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                          required
                        />
                      </div>
                    </div>
                    <div className="mt-4">
                      <label className="block text-sm font-medium text-gray-400 mb-2">Phone</label>
                      <input
                        type="tel"
                        value={checkoutForm.phone}
                        onChange={(e) => setCheckoutForm({ ...checkoutForm, phone: e.target.value })}
                        placeholder="+44 123 456 7890"
                        className="w-full bg-gray-800/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {/* Shipping Address */}
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-blue-400" />
                      Shipping Address
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-400 mb-2">Street Address</label>
                        <input
                          type="text"
                          value={checkoutForm.address}
                          onChange={(e) => setCheckoutForm({ ...checkoutForm, address: e.target.value })}
                          placeholder="123 Research Street"
                          className="w-full bg-gray-800/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                          required
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-400 mb-2">City</label>
                          <input
                            type="text"
                            value={checkoutForm.city}
                            onChange={(e) => setCheckoutForm({ ...checkoutForm, city: e.target.value })}
                            placeholder="London"
                            className="w-full bg-gray-800/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-400 mb-2">Postcode</label>
                          <input
                            type="text"
                            value={checkoutForm.postcode}
                            onChange={(e) => setCheckoutForm({ ...checkoutForm, postcode: e.target.value })}
                            placeholder="SW1A 1AA"
                            className="w-full bg-gray-800/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                            required
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Payment Method */}
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <CreditCard className="w-5 h-5 text-blue-400" />
                      Payment Method
                    </h3>
                    
                    {/* Card Payment */}
                    <button
                      onClick={() => setCheckoutForm({ ...checkoutForm, paymentMethod: 'card' })}
                      className={`w-full flex items-center gap-4 p-4 rounded-xl border transition-all mb-3 ${
                        checkoutForm.paymentMethod === 'card'
                          ? 'bg-blue-600/20 border-blue-500'
                          : 'bg-gray-800/50 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                        <span className="text-xl">💳</span>
                      </div>
                      <div className="text-left flex-1">
                        <p className="font-medium text-white">Credit/Debit Card</p>
                        <p className="text-xs text-gray-400">Secure payment via Stripe</p>
                      </div>
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                        checkoutForm.paymentMethod === 'card' ? 'border-blue-500 bg-blue-500' : 'border-gray-600'
                      }`}>
                        {checkoutForm.paymentMethod === 'card' && <div className="w-2 h-2 rounded-full bg-white" />}
                      </div>
                    </button>
                    
                    {checkoutForm.paymentMethod === 'card' && (
                      <div className="mb-4 p-4 bg-gray-800/30 rounded-xl border border-white/10">
                        <p className="text-sm text-gray-400 mb-3">You'll be redirected to Stripe secure checkout</p>
                        <div className="flex gap-2 text-2xl">
                          <span>💳</span><span>🅿️</span><span>💰</span>
                        </div>
                      </div>
                    )}

                    {/* PayPal */}
                    <button
                      onClick={() => setCheckoutForm({ ...checkoutForm, paymentMethod: 'paypal' })}
                      className={`w-full flex items-center gap-4 p-4 rounded-xl border transition-all mb-3 ${
                        checkoutForm.paymentMethod === 'paypal'
                          ? 'bg-blue-600/20 border-blue-500'
                          : 'bg-gray-800/50 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                        <span className="text-xl text-white font-bold">P</span>
                      </div>
                      <div className="text-left flex-1">
                        <p className="font-medium text-white">PayPal</p>
                        <p className="text-xs text-gray-400">Pay with your PayPal account</p>
                      </div>
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                        checkoutForm.paymentMethod === 'paypal' ? 'border-blue-500 bg-blue-500' : 'border-gray-600'
                      }`}>
                        {checkoutForm.paymentMethod === 'paypal' && <div className="w-2 h-2 rounded-full bg-white" />}
                      </div>
                    </button>

                    {checkoutForm.paymentMethod === 'paypal' && (
                      <div className="mb-4 p-4 bg-blue-500/10 rounded-xl border border-blue-500/20">
                        <p className="text-sm text-gray-400">Pay securely with your PayPal balance or linked cards</p>
                      </div>
                    )}

                    {/* Bank Transfer */}
                    <button
                      onClick={() => setCheckoutForm({ ...checkoutForm, paymentMethod: 'bank' })}
                      className={`w-full flex items-center gap-4 p-4 rounded-xl border transition-all ${
                        checkoutForm.paymentMethod === 'bank'
                          ? 'bg-blue-600/20 border-blue-500'
                          : 'bg-gray-800/50 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
                        <span className="text-xl">🏦</span>
                      </div>
                      <div className="text-left flex-1">
                        <p className="font-medium text-white">Bank Transfer</p>
                        <p className="text-xs text-gray-400">Manual bank transfer (slower)</p>
                      </div>
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                        checkoutForm.paymentMethod === 'bank' ? 'border-blue-500 bg-blue-500' : 'border-gray-600'
                      }`}>
                        {checkoutForm.paymentMethod === 'bank' && <div className="w-2 h-2 rounded-full bg-white" />}
                      </div>
                    </button>

                    {checkoutForm.paymentMethod === 'bank' && (
                      <div className="mt-3 p-4 bg-gray-800/30 rounded-xl border border-white/10">
                        <p className="text-sm text-gray-400 mb-2">Bank details will be provided after order placement</p>
                        <p className="text-xs text-amber-400">⚠️ Order ships after payment confirmation</p>
                      </div>
                    )}
                  </div>

                  {/* Order Summary */}
                  <div className="bg-gray-800/50 rounded-xl p-4 border border-white/10">
                    <h4 className="font-semibold text-white mb-3 flex items-center gap-2">
                      <Package className="w-5 h-5 text-blue-400" />
                      Order Summary
                    </h4>
                    <div className="space-y-2">
                      {cart.map((item) => (
                        <div key={item.id} className="flex items-center justify-between text-sm">
                          <span className="text-gray-400">{item.name} {item.dosage} x{item.quantity}</span>
                          <span className="text-white">£{(parseFloat(item.price.replace('£', '')) * item.quantity).toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                    <div className="border-t border-white/10 mt-3 pt-3 flex items-center justify-between">
                      <span className="font-semibold text-white">Total</span>
                      <span className="text-xl font-bold text-white">£{getTotalPrice()}</span>
                    </div>
                  </div>
                </div>
              ) : (
                /* Cart Items */
                <>
                  {cart.length === 0 ? (
                    <div className="p-6 flex flex-col items-center justify-center h-full text-center">
                      <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center mb-4">
                        <ShoppingCart className="w-10 h-10 text-gray-500" />
                      </div>
                      <p className="text-gray-400 mb-4">Your cart is empty</p>
                      <Link
                        to="/products"
                        onClick={closeCart}
                        className="bg-blue-600 text-white px-6 py-2.5 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
                      >
                        Shop Now
                      </Link>
                    </div>
                  ) : (
                    <div className="p-6 space-y-4">
                      {cart.map((item) => (
                        <div
                          key={item.id}
                          className="flex gap-4 bg-gray-800/50 rounded-xl p-4 border border-white/10"
                        >
                          <div className="w-20 h-20 bg-gray-900 rounded-lg flex items-center justify-center flex-shrink-0">
                            <Package className="w-8 h-8 text-gray-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-semibold text-white truncate">{item.name}</h3>
                            <p className="text-sm text-gray-400">{item.dosage}</p>
                            <p className="text-blue-400 font-medium mt-1">{item.price}</p>
                            <div className="flex items-center justify-between mt-2">
                              <div className="flex items-center gap-2 bg-gray-900 rounded-lg border border-white/10">
                                <button
                                  onClick={() => updateQuantity(item.id, -1)}
                                  className="p-1.5 hover:bg-gray-800 rounded-l-lg text-gray-400"
                                >
                                  <Minus className="w-4 h-4" />
                                </button>
                                <span className="w-8 text-center text-sm font-medium text-white">{item.quantity}</span>
                                <button
                                  onClick={() => updateQuantity(item.id, 1)}
                                  className="p-1.5 hover:bg-gray-800 rounded-r-lg text-gray-400"
                                >
                                  <Plus className="w-4 h-4" />
                                </button>
                              </div>
                              <button
                                onClick={() => removeItem(item.id)}
                                className="p-2 text-gray-500 hover:text-red-400 transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Scroll Buttons - Right Side */}
            {showCheckout && (
              <div className="absolute right-3 top-1/2 -translate-y-1/2 z-10 flex flex-col gap-2">
                <button
                  onClick={() => {
                    const scrollContainer = document.querySelector('.checkout-scroll-container');
                    if (scrollContainer) {
                      scrollContainer.scrollBy({ top: -200, behavior: 'smooth' });
                    }
                  }}
                  className="bg-gray-800/80 hover:bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center shadow-lg transition-colors"
                  title="Scroll Up"
                >
                  <ChevronLeft className="w-4 h-4 rotate-90" />
                </button>
                <button
                  onClick={() => {
                    const scrollContainer = document.querySelector('.checkout-scroll-container');
                    if (scrollContainer) {
                      scrollContainer.scrollBy({ top: 200, behavior: 'smooth' });
                    }
                  }}
                  className="bg-gray-800/80 hover:bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center shadow-lg transition-colors"
                  title="Scroll Down"
                >
                  <ChevronLeft className="w-4 h-4 rotate-[-90deg]" />
                </button>
              </div>
            )}

            {/* Footer */}
            {!orderPlaced && (
              <div className="border-t border-white/10 p-6 space-y-4 bg-gray-900" style={{ flexShrink: 0 }}>
                {showCheckout ? (
                  <>
                    <div className="flex gap-3">
                      <button
                        onClick={handleCheckout}
                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-4 rounded-xl font-medium transition-all flex items-center justify-center gap-2"
                      >
                        <CheckCircle2 className="w-5 h-5" />
                        Place Order - £{getTotalPrice()}
                      </button>
                    </div>
                  </>
                ) : cart.length > 0 && (
                  <>
                    <div className="flex items-center justify-between text-lg font-semibold">
                      <span className="text-gray-400">Total</span>
                      <span className="text-white">£{getTotalPrice()}</span>
                    </div>
                    <div className="flex gap-3">
                      <button
                        onClick={() => setShowCheckout(true)}
                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-4 rounded-xl font-medium transition-all flex items-center justify-center gap-2"
                      >
                        Proceed to Checkout
                        <ShoppingCart className="w-5 h-5" />
                      </button>
                    </div>
                    <p className="text-xs text-gray-500 text-center">
                      Free shipping on orders over £100
                    </p>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="pt-20">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 border-t border-white/10 py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            {/* Brand */}
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <img
                  src="https://cdn.wegic.ai/assets/onepage/agent/images/1773234372536_edited.png"
                  alt="Pro Health Peptides"
                  className="w-8 h-8 object-contain"
                />
                <span className="text-lg font-bold text-white">Pro Health Peptides</span>
              </div>
              <p className="text-gray-400 text-sm max-w-sm">
                Premium research peptides for scientific applications. 99%+ purity guaranteed. For laboratory research use only.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-white font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <a href="/products" className="text-gray-400 hover:text-white transition-colors text-sm">Products</a>
                </li>
                <li>
                  <a href="/#about" className="text-gray-400 hover:text-white transition-colors text-sm">About Us</a>
                </li>
                <li>
                  <a href="/#contact" className="text-gray-400 hover:text-white transition-colors text-sm">Contact</a>
                </li>
              </ul>
            </div>

            {/* Resources */}
            <div>
              <h4 className="text-white font-semibold mb-4">Resources</h4>
              <ul className="space-y-2">
                <li>
                  <a href="/terms" className="text-gray-400 hover:text-white transition-colors text-sm">Terms & Conditions</a>
                </li>
                <li>
                  <a href="/privacy" className="text-gray-400 hover:text-white transition-colors text-sm">Privacy Policy</a>
                </li>
                <li>
                  <a href="/storage-guide" className="text-gray-400 hover:text-white transition-colors text-sm">Storage Guide</a>
                </li>
                <li>
                  <a href="/admin" className="text-gray-400 hover:text-white transition-colors text-sm">Admin Panel</a>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom */}
          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-500 text-sm">
              &copy; {new Date().getFullYear()} Pro Health Peptides. All rights reserved.
            </p>
            <p className="text-gray-500 text-xs">
              For laboratory research use only. Not for human consumption.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
