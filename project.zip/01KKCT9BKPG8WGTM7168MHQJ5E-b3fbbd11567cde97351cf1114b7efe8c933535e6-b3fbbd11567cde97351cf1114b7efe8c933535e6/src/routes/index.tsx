import { createBrowserRouter, Outlet } from 'react-router-dom';
import { lazy, Suspense } from 'react';
import { Layout } from '@/components/Layout';
import ScrollToTop from '@/components/ScrollToTop';

// Retry wrapper for lazy loading
const lazyWithRetry = (importFn: () => Promise<any>) => {
  return lazy(() => {
    return new Promise((resolve, reject) => {
      const attempt = () => {
        importFn()
          .then(resolve)
          .catch((error: Error) => {
            console.error('Failed to load chunk, retrying...', error);
            // Retry after a short delay
            setTimeout(() => {
              importFn()
                .then(resolve)
                .catch(reject);
            }, 1000);
          });
      };
      attempt();
    });
  });
};

const Home = lazyWithRetry(() => import('@/pages/Home'));
const Products = lazyWithRetry(() => import('@/pages/Products'));
const ProductDetail = lazyWithRetry(() => import('@/pages/ProductDetail'));
const Terms = lazyWithRetry(() => import('@/pages/Terms'));
const StorageGuide = lazyWithRetry(() => import('@/pages/StorageGuide'));
const Privacy = lazyWithRetry(() => import('@/pages/Privacy'));
const Account = lazyWithRetry(() => import('@/pages/Account'));
const Register = lazyWithRetry(() => import('@/pages/Register'));
const Login = lazyWithRetry(() => import('@/pages/Login'));
const Admin = lazyWithRetry(() => import('@/pages/Admin'));
const NotFound = lazyWithRetry(() => import('@/pages/NotFound'));

import { ErrorBoundary } from '@/components/ErrorBoundary';

function AppLayout() {
  return (
    <>
      <ScrollToTop />
      <Layout>
        <ErrorBoundary>
          <Suspense fallback={
            <div className="min-h-screen bg-gray-900 flex items-center justify-center">
              <div className="flex flex-col items-center gap-4">
                <div className="w-12 h-12 border-4 border-blue-900/50 border-t-blue-400 rounded-full animate-spin"></div>
                <p className="text-gray-400">Loading...</p>
              </div>
            </div>
          }>
            <Outlet />
          </Suspense>
        </ErrorBoundary>
      </Layout>
    </>
  );
}

export const router = createBrowserRouter([
  {
    path: '/',
    element: <AppLayout />,
    children: [
      {
        index: true,
        element: <Home />,
      },
      {
        path: 'products',
        element: <Products />,
      },
      {
        path: 'products/:id',
        element: <ProductDetail />,
      },
      {
        path: 'terms',
        element: <Terms />,
      },
      {
        path: 'storage-guide',
        element: <StorageGuide />,
      },
      {
        path: 'privacy',
        element: <Privacy />,
      },
      {
        path: 'account',
        element: <Account />,
      },
      {
        path: 'register',
        element: <Register />,
      },
      {
        path: 'login',
        element: <Login />,
      },
      {
        path: 'admin',
        element: <Admin />,
      },
      {
        path: '*',
        element: <NotFound />,
      },
    ],
  },
]);
