import { motion } from 'framer-motion';
import { Search, ShoppingCart, Filter, FlaskConical, CheckCircle2 } from 'lucide-react';
import { useState, useEffect } from 'react';

interface CartItem {
  id: number;
  name: string;
  dosage: string;
  price: string;
  quantity: number;
}

const categories = [
  { id: 'all', name: 'All Products', count: 21 },
  { id: 'metabolic', name: 'Metabolic', count: 6 },
  { id: 'healing', name: 'Healing & Recovery', count: 3 },
  { id: 'longevity', name: 'Longevity', count: 5 },
  { id: 'cosmetic', name: 'Cosmetic', count: 3 },
  { id: 'performance', name: 'Performance', count: 1 },
  { id: 'blends', name: 'Blends', count: 2 },
  { id: 'accessories', name: 'Accessories', count: 1 },
];

const products = [
  {
    id: 1,
    name: 'Retatrutide',
    dosage: '10 mg',
    purity: '99%+',
    price: '£57.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194662805.jpg?imageMogr2/format/webp',
    category: 'metabolic',
    description: 'A triple hormone receptor agonist (GCGR, GIPR, GLP-1R) studied for metabolic research including glucose regulation and energy expenditure.',
    research: 'Used in studies examining metabolic pathways, glucose homeostasis, and body composition research.'
  },
  {
    id: 2,
    name: 'Retatrutide',
    dosage: '20 mg',
    purity: '99%+',
    price: '£94.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194662506.jpg?imageMogr2/format/webp',
    category: 'metabolic',
    description: 'A triple hormone receptor agonist (GCGR, GIPR, GLP-1R) studied for metabolic research including glucose regulation and energy expenditure.',
    research: 'Used in studies examining metabolic pathways, glucose homeostasis, and body composition research.'
  },
  {
    id: 3,
    name: 'Tirzepatide',
    dosage: '10 mg',
    purity: '99%+',
    price: '£39.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194662810.jpg?imageMogr2/format/webp',
    category: 'metabolic',
    description: 'A dual GIP/GLP-1 receptor agonist studied for metabolic research including insulin secretion and glucagon regulation.',
    research: 'Used in research investigating glucose control, metabolic function, and pancreatic beta cell studies.'
  },
  {
    id: 4,
    name: 'Tirzepatide',
    dosage: '20 mg',
    purity: '99%+',
    price: '£69.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194663214.jpg?imageMogr2/format/webp',
    category: 'metabolic',
    description: 'A dual GIP/GLP-1 receptor agonist studied for metabolic research including insulin secretion and glucagon regulation.',
    research: 'Used in research investigating glucose control, metabolic function, and pancreatic beta cell studies.'
  },
  {
    id: 5,
    name: 'Tirzepatide',
    dosage: '30 mg',
    purity: '99%+',
    price: '£84.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194661704.jpg?imageMogr2/format/webp',
    category: 'metabolic',
    description: 'A dual GIP/GLP-1 receptor agonist studied for metabolic research including insulin secretion and glucagon regulation.',
    research: 'Used in research investigating glucose control, metabolic function, and pancreatic beta cell studies.'
  },
  {
    id: 6,
    name: 'Tirzepatide',
    dosage: '60 mg',
    purity: '99%+',
    price: '£119.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194662812.jpg?imageMogr2/format/webp',
    category: 'metabolic',
    description: 'A dual GIP/GLP-1 receptor agonist studied for metabolic research including insulin secretion and glucagon regulation.',
    research: 'Used in research investigating glucose control, metabolic function, and pancreatic beta cell studies.'
  },
  {
    id: 7,
    name: 'KPV',
    dosage: '10 mg',
    purity: '99%+',
    price: '£19.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194698906.jpg?imageMogr2/format/webp',
    category: 'healing',
    description: 'A tripeptide (Lysine-Proline-Valine) studied for its anti-inflammatory properties and immune modulation research.',
    research: 'Used in studies examining inflammatory responses, immune system function, and tissue repair mechanisms.'
  },
  {
    id: 8,
    name: 'MOTS-c',
    dosage: '10 mg',
    purity: '99%+',
    price: '£19.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194698807.jpg?imageMogr2/format/webp',
    category: 'longevity',
    description: 'A mitochondrial-derived peptide studied for metabolic regulation, cellular energy production, and longevity research.',
    research: 'Used in research on mitochondrial function, metabolic homeostasis, and age-related cellular studies.'
  },
  {
    id: 9,
    name: 'BPC-157',
    dosage: '10 mg',
    purity: '99%+',
    price: '£19.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194698301.jpg?imageMogr2/format/webp',
    category: 'healing',
    description: 'A synthetic pentadecapeptide studied for tissue regeneration, wound healing, and musculoskeletal repair research.',
    research: 'Used in studies examining tendon healing, muscle repair, gastrointestinal healing, and connective tissue research.'
  },
  {
    id: 10,
    name: 'TB-500',
    dosage: '10 mg',
    purity: '99%+',
    price: '£24.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194699407.jpg?imageMogr2/format/webp',
    category: 'healing',
    description: 'A synthetic version of thymosin beta-4 studied for cellular migration, tissue repair, and regenerative medicine.',
    research: 'Used in research on wound healing, tissue regeneration, cellular migration, and muscle recovery studies.'
  },
  {
    id: 11,
    name: 'PT-141',
    dosage: '10 mg',
    purity: '99%+',
    price: '£14.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194698306.jpg?imageMogr2/format/webp',
    category: 'performance',
    description: 'A melanocortin receptor agonist studied for neurological and sexual dysfunction research applications.',
    research: 'Used in studies examining central nervous system mechanisms, neural pathways, and related physiological research.'
  },
  {
    id: 12,
    name: 'NAD+',
    dosage: '100 mg',
    purity: '99%+',
    price: '£20.00',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194699408.jpg?imageMogr2/format/webp',
    category: 'longevity',
    description: 'Nicotinamide adenine dinucleotide studied for cellular energy metabolism, DNA repair, and sirtuin activation research.',
    research: 'Used in studies on cellular metabolism, mitochondrial function, aging mechanisms, and metabolic disorders.'
  },
  {
    id: 13,
    name: 'NAD+',
    dosage: '250 mg',
    purity: '99%+',
    price: '£28.00',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769303.jpg?imageMogr2/format/webp',
    category: 'longevity',
    description: 'Nicotinamide adenine dinucleotide studied for cellular energy metabolism, DNA repair, and sirtuin activation research.',
    research: 'Used in studies on cellular metabolism, mitochondrial function, aging mechanisms, and metabolic disorders.'
  },
  {
    id: 14,
    name: 'NAD+',
    dosage: '500 mg',
    purity: '99%+',
    price: '£52.00',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769404.jpg?imageMogr2/format/webp',
    category: 'longevity',
    description: 'Nicotinamide adenine dinucleotide studied for cellular energy metabolism, DNA repair, and sirtuin activation research.',
    research: 'Used in studies on cellular metabolism, mitochondrial function, aging mechanisms, and metabolic disorders.'
  },
  {
    id: 15,
    name: 'NAD+',
    dosage: '1000 mg',
    purity: '99%+',
    price: '£90.00',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769405.jpg?imageMogr2/format/webp',
    category: 'longevity',
    description: 'Nicotinamide adenine dinucleotide studied for cellular energy metabolism, DNA repair, and sirtuin activation research.',
    research: 'Used in studies on cellular metabolism, mitochondrial function, aging mechanisms, and metabolic disorders.'
  },
  {
    id: 16,
    name: 'GHK-Cu',
    dosage: '50 mg',
    purity: '99%+',
    price: '£24.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194780018.jpg?imageMogr2/format/webp',
    category: 'cosmetic',
    description: 'Copper peptide studied for skin regeneration, collagen production, and tissue repair in dermatological research.',
    research: 'Used in studies on skin healing, collagen synthesis, hair follicle research, and cosmetic applications.'
  },
  {
    id: 17,
    name: 'GHK-Cu',
    dosage: '100 mg',
    purity: '99%+',
    price: '£34.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194770307.jpg?imageMogr2/format/webp',
    category: 'cosmetic',
    description: 'Copper peptide studied for skin regeneration, collagen production, and tissue repair in dermatological research.',
    research: 'Used in studies on skin healing, collagen synthesis, hair follicle research, and cosmetic applications.'
  },
  {
    id: 18,
    name: 'Bacteriostatic Water',
    dosage: '10 ml',
    purity: 'Sterile',
    price: '£6.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769606.jpg?imageMogr2/format/webp',
    category: 'accessories',
    description: 'Sterile water containing 0.9% benzyl alcohol used for reconstituting lyophilized peptides in laboratory settings.',
    research: 'Essential solvent for peptide reconstitution. Benzyl alcohol prevents bacterial growth in solution.'
  },
  {
    id: 19,
    name: 'GLOW',
    dosage: '70 mg',
    purity: '99%+',
    price: '£56.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769607.jpg?imageMogr2/format/webp',
    category: 'blends',
    description: 'A synergistic peptide blend combining multiple growth factors for enhanced tissue regeneration research.',
    research: 'Used in studies examining combined peptide effects on tissue repair, cellular regeneration, and healing mechanisms.'
  },
  {
    id: 20,
    name: 'CLOW',
    dosage: '80 mg',
    purity: '99%+',
    price: '£63.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769808.jpg?imageMogr2/format/webp',
    category: 'blends',
    description: 'An advanced peptide blend formulated for comprehensive cellular optimization and metabolic support research.',
    research: 'Used in studies investigating multi-pathway cellular effects, metabolic enhancement, and synergistic peptide interactions.'
  },
  {
    id: 21,
    name: 'Melanotan II',
    dosage: '10 mg',
    purity: '99%+',
    price: '£12.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769809.jpg?imageMogr2/format/webp',
    category: 'cosmetic',
    description: 'A synthetic melanocortin peptide studied for melanogenesis, skin pigmentation, and related dermatological research.',
    research: 'Used in studies on melanin production, skin pigmentation mechanisms, and UV protection research applications.'
  }
];

export default function Products() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [clickedProductId, setClickedProductId] = useState<number | null>(null);

  // Load cart items
  const loadCart = () => {
    const cart = JSON.parse(localStorage.getItem('php_cart') || '[]') as CartItem[];
    setCartItems(cart);
  };

  useEffect(() => {
    loadCart();
    const handleCartUpdate = () => {
      loadCart();
    };

    window.addEventListener('cartUpdated', handleCartUpdate);
    return () => window.removeEventListener('cartUpdated', handleCartUpdate);
  }, []);

  // Get quantity for a product
  const getProductQuantity = (productId: number) => {
    const item = cartItems.find((item) => item.id === productId);
    return item ? item.quantity : 0;
  };

  const filteredProducts = products.filter(product => {
    const matchesCategory = activeCategory === 'all' || product.category === activeCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const addToCart = (product: typeof products[0]) => {
    // Visual feedback - set clicked state
    setClickedProductId(product.id);
    setTimeout(() => setClickedProductId(null), 300);

    const cart = JSON.parse(localStorage.getItem('php_cart') || '[]') as CartItem[];
    const existing = cart.find((item: CartItem) => item.id === product.id);
    if (existing) {
      existing.quantity += 1;
    } else {
      cart.push({
        id: product.id,
        name: product.name,
        dosage: product.dosage,
        price: product.price,
        quantity: 1
      });
    }
    localStorage.setItem('php_cart', JSON.stringify(cart));
    setCartItems(cart);
    window.dispatchEvent(new Event('cartUpdated'));
  };

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gray-900/50 backdrop-blur-sm border-b border-white/10 relative z-10">
        <div className="container mx-auto px-6 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Our Products</h1>
              <p className="text-gray-400">Premium research peptides for scientific applications</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-2.5 bg-gray-800/50 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 w-64 text-white placeholder-gray-500"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Banner */}
      <div className="relative w-full h-64 md:h-80 lg:h-96 overflow-hidden">
        <img
          src="https://cdn.wegic.ai/assets/onepage/uploads/2031481443271393281/image/2026/03/11/01KKDHBV166HXSXDJFRYGKADXK.jpg?imageMogr2/format/webp"
          alt="Research peptides vials in laboratory refrigerator - KPV, NAD+, TB-500"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/30 to-transparent" />
      </div>

      <div className="container mx-auto px-6 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar - Categories */}
          <aside className="lg:w-64 flex-shrink-0">
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl border border-white/10 p-6 sticky top-24">
              <div className="flex items-center gap-2 mb-6">
                <Filter className="w-5 h-5 text-gray-400" />
                <h2 className="font-semibold text-white">Categories</h2>
              </div>
              <nav className="space-y-1">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setActiveCategory(category.id)}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                      activeCategory === category.id
                        ? 'bg-blue-500/20 text-blue-400'
                        : 'text-gray-400 hover:bg-white/5'
                    }`}
                  >
                    <span>{category.name}</span>
                    <span className={`text-xs ${activeCategory === category.id ? 'text-blue-400' : 'text-gray-500'}`}>
                      {category.count}
                    </span>
                  </button>
                ))}
              </nav>

              {/* Research Notice */}
              <div className="mt-8 p-4 bg-amber-900/20 rounded-lg border border-amber-500/30">
                <div className="flex items-start gap-3">
                  <FlaskConical className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-medium text-amber-300 text-sm">For Research Only</h3>
                    <p className="text-xs text-amber-400/80 mt-1">
                      All products are intended for laboratory research purposes only. Not for human consumption.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </aside>

          {/* Products Grid */}
          <main className="flex-1">
            <div className="mb-6 flex items-center justify-between">
              <p className="text-gray-400">
                Showing <span className="font-semibold text-white">{filteredProducts.length}</span> products
              </p>
            </div>

            {filteredProducts.length === 0 ? (
              <div className="text-center py-16 bg-gray-800/30 rounded-2xl border border-white/10">
                <Search className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-white mb-2">No products found</h3>
                <p className="text-gray-400">Try adjusting your search or category filter</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredProducts.map((product, index) => {
                  const quantity = getProductQuantity(product.id);
                  const isClicked = clickedProductId === product.id;
                  return (
                    <motion.div
                      key={product.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="group bg-gray-800/50 border border-white/10 rounded-2xl overflow-hidden hover:border-blue-500/30 transition-all flex flex-col"
                    >
                      {/* Product Image */}
                      <div className="aspect-square bg-gray-800/50 p-6 relative">
                        <img
                          src={product.image}
                          alt={`${product.name} ${product.dosage}`}
                          className="w-full h-full object-contain group-hover:scale-105 transition-transform"
                        />
                        <div className="absolute top-4 right-4 bg-green-500/20 text-green-400 px-3 py-1 rounded-full text-xs font-medium">
                          {product.purity}
                        </div>
                        <div className="absolute top-4 left-4 bg-blue-500/20 text-blue-400 px-3 py-1 rounded-full text-xs font-medium capitalize">
                          {product.category}
                        </div>
                        {/* Quantity Badge */}
                        {quantity > 0 && (
                          <div className="absolute bottom-4 left-4 bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                            <ShoppingCart className="w-3 h-3" />
                            {quantity} in cart
                          </div>
                        )}
                        <div
                          onClick={() => addToCart(product)}
                          className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                        >
                          <span className="bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-medium">Add to Cart</span>
                        </div>
                      </div>

                      {/* Product Info */}
                      <div className="p-6 flex-1 flex flex-col">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="text-lg font-semibold text-white">{product.name}</h3>
                          <span className="text-lg font-bold text-white">{product.price}</span>
                        </div>
                        <p className="text-blue-400 font-medium text-sm mb-3">{product.dosage}</p>
                        <p className="text-sm text-white mb-4 line-clamp-2 flex-1">{product.description}</p>

                        <button
                          onClick={() => addToCart(product)}
                          className={`w-full py-3 rounded-xl font-medium transition-all duration-150 flex items-center justify-center gap-2 ${
                            isClicked
                              ? 'bg-green-600 scale-95'
                              : quantity > 0
                              ? 'bg-blue-700 hover:bg-blue-600'
                              : 'bg-blue-600 hover:bg-blue-700'
                          } text-white`}
                        >
                          {isClicked ? (
                            <>
                              <CheckCircle2 className="w-4 h-4" />
                              Added!
                            </>
                          ) : (
                            <>
                              <ShoppingCart className="w-4 h-4" />
                              {quantity > 0 ? `Add Another (${quantity})` : 'Add to Cart'}
                            </>
                          )}
                        </button>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
