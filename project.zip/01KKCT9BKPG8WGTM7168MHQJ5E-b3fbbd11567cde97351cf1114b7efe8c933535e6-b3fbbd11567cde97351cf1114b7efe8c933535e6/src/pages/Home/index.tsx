import { motion } from 'framer-motion';
import { ArrowRight, CheckCircle2, ShieldCheck, FlaskConical, Zap, Mail, Phone, Beaker, Microscope, Quote, Star, CreditCard, Truck, Award, X, ShoppingBag, User } from 'lucide-react';
import { useState, useEffect } from 'react';

interface CartItem {
  id: number;
  name: string;
  dosage: string;
  price: string;
  quantity: number;
}

const fadeIn = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.15 }
  }
};

const products = [
  {
    id: 1,
    name: 'Retatrutide',
    dosage: '10 mg',
    purity: '99%+',
    price: '£57.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194662805.jpg?imageMogr2/format/webp',
    category: 'Metabolic',
    description: 'A triple hormone receptor agonist (GCGR, GIPR, GLP-1R) studied for metabolic research including glucose regulation and energy expenditure.',
    research: 'Used in studies examining metabolic pathways, glucose homeostasis, and body composition research.'
  },
  {
    id: 2,
    name: 'Retatrutide',
    dosage: '20 mg',
    purity: '99%+',
    price: '£94.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194662506.jpg?imageMogr2/format/webp',
    category: 'Metabolic',
    description: 'A triple hormone receptor agonist (GCGR, GIPR, GLP-1R) studied for metabolic research including glucose regulation and energy expenditure.',
    research: 'Used in studies examining metabolic pathways, glucose homeostasis, and body composition research.'
  },
  {
    id: 3,
    name: 'Tirzepatide',
    dosage: '10 mg',
    purity: '99%+',
    price: '£39.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194662810.jpg?imageMogr2/format/webp',
    category: 'Metabolic',
    description: 'A dual GIP/GLP-1 receptor agonist studied for metabolic research including insulin secretion and glucagon regulation.',
    research: 'Used in research investigating glucose control, metabolic function, and pancreatic beta cell studies.'
  },
  {
    id: 4,
    name: 'Tirzepatide',
    dosage: '20 mg',
    purity: '99%+',
    price: '£69.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194663214.jpg?imageMogr2/format/webp',
    category: 'Metabolic',
    description: 'A dual GIP/GLP-1 receptor agonist studied for metabolic research including insulin secretion and glucagon regulation.',
    research: 'Used in research investigating glucose control, metabolic function, and pancreatic beta cell studies.'
  },
  {
    id: 5,
    name: 'Tirzepatide',
    dosage: '30 mg',
    purity: '99%+',
    price: '£84.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194661704.jpg?imageMogr2/format/webp',
    category: 'Metabolic',
    description: 'A dual GIP/GLP-1 receptor agonist studied for metabolic research including insulin secretion and glucagon regulation.',
    research: 'Used in research investigating glucose control, metabolic function, and pancreatic beta cell studies.'
  },
  {
    id: 6,
    name: 'Tirzepatide',
    dosage: '60 mg',
    purity: '99%+',
    price: '£119.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194662812.jpg?imageMogr2/format/webp',
    category: 'Metabolic',
    description: 'A dual GIP/GLP-1 receptor agonist studied for metabolic research including insulin secretion and glucagon regulation.',
    research: 'Used in research investigating glucose control, metabolic function, and pancreatic beta cell studies.'
  },
  {
    id: 7,
    name: 'BPC-157',
    dosage: '10 mg',
    purity: '99%+',
    price: '£19.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194698301.jpg?imageMogr2/format/webp',
    category: 'Healing',
    description: 'A synthetic pentadecapeptide studied for tissue regeneration, wound healing, and musculoskeletal repair research.',
    research: 'Used in studies on tendon and ligament healing, muscle recovery, and gastrointestinal protective mechanisms.'
  },
  {
    id: 8,
    name: 'TB-500',
    dosage: '10 mg',
    purity: '99%+',
    price: '£24.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194699407.jpg?imageMogr2/format/webp',
    category: 'Healing',
    description: 'A synthetic version of thymosin beta-4 studied for cellular migration, tissue repair, and regenerative medicine.',
    research: 'Applied in wound healing studies, tissue regeneration, and cellular migration research.'
  },
  {
    id: 9,
    name: 'KPV',
    dosage: '10 mg',
    purity: '99%+',
    price: '£19.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194698906.jpg?imageMogr2/format/webp',
    category: 'Anti-Inflammatory',
    description: 'A tripeptide (Lysine-Proline-Valine) studied for its anti-inflammatory properties and immune modulation research.',
    research: 'Used in studies on inflammatory responses, immune system modulation, and related cellular pathways.'
  },
  {
    id: 10,
    name: 'MOTS-c',
    dosage: '10 mg',
    purity: '99%+',
    price: '£19.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194698807.jpg?imageMogr2/format/webp',
    category: 'Longevity',
    description: 'A mitochondrial-derived peptide studied for metabolic regulation, cellular energy production, and longevity research.',
    research: 'Applied in metabolic regulation studies, cellular energy research, and aging mechanism investigations.'
  },
  {
    id: 11,
    name: 'PT-141',
    dosage: '10 mg',
    purity: '99%+',
    price: '£14.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194698306.jpg?imageMogr2/format/webp',
    category: 'Performance',
    description: 'A melanocortin receptor agonist studied for neurological and sexual dysfunction research applications.',
    research: 'Used in studies on neurological pathways, melanocortin systems, and related receptor research.'
  },
  {
    id: 12,
    name: 'NAD+',
    dosage: '100 mg',
    purity: '99%+',
    price: '£20.00',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194699408.jpg?imageMogr2/format/webp',
    category: 'Longevity',
    description: 'Nicotinamide adenine dinucleotide studied for cellular energy metabolism, DNA repair, and sirtuin activation research.',
    research: 'Used in studies on cellular metabolism, mitochondrial function, aging mechanisms, and metabolic disorders.'
  },
  {
    id: 13,
    name: 'NAD+',
    dosage: '250 mg',
    purity: '99%+',
    price: '£28.00',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769303.jpg?imageMogr2/format/webp',
    category: 'Longevity',
    description: 'Nicotinamide adenine dinucleotide studied for cellular energy metabolism, DNA repair, and sirtuin activation research.',
    research: 'Used in studies on cellular metabolism, mitochondrial function, aging mechanisms, and metabolic disorders.'
  },
  {
    id: 14,
    name: 'NAD+',
    dosage: '500 mg',
    purity: '99%+',
    price: '£52.00',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769404.jpg?imageMogr2/format/webp',
    category: 'Longevity',
    description: 'Nicotinamide adenine dinucleotide studied for cellular energy metabolism, DNA repair, and sirtuin activation research.',
    research: 'Used in studies on cellular metabolism, mitochondrial function, aging mechanisms, and metabolic disorders.'
  },
  {
    id: 15,
    name: 'NAD+',
    dosage: '1000 mg',
    purity: '99%+',
    price: '£90.00',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769405.jpg?imageMogr2/format/webp',
    category: 'Longevity',
    description: 'Nicotinamide adenine dinucleotide studied for cellular energy metabolism, DNA repair, and sirtuin activation research.',
    research: 'Used in studies on cellular metabolism, mitochondrial function, aging mechanisms, and metabolic disorders.'
  },
  {
    id: 16,
    name: 'GHK-Cu',
    dosage: '50 mg',
    purity: '99%+',
    price: '£24.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194780018.jpg?imageMogr2/format/webp',
    category: 'Cosmetic',
    description: 'Copper peptide studied for skin regeneration, collagen production, and tissue repair in dermatological research.',
    research: 'Applied in dermatological studies, skin regeneration research, and cosmetic peptide investigations.'
  },
  {
    id: 17,
    name: 'GHK-Cu',
    dosage: '100 mg',
    purity: '99%+',
    price: '£34.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194770307.jpg?imageMogr2/format/webp',
    category: 'Cosmetic',
    description: 'Copper peptide studied for skin regeneration, collagen production, and tissue repair in dermatological research.',
    research: 'Applied in dermatological studies, skin regeneration research, and cosmetic peptide investigations.'
  },
  {
    id: 18,
    name: 'Bacteriostatic Water',
    dosage: '10 ml',
    purity: 'Sterile',
    price: '£6.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769606.jpg?imageMogr2/format/webp',
    category: 'Accessories',
    description: 'Sterile water containing 0.9% benzyl alcohol used for reconstituting lyophilized peptides in laboratory settings.',
    research: 'Laboratory accessory for proper peptide reconstitution and preparation.'
  },
  {
    id: 19,
    name: 'GLOW',
    dosage: '70 mg',
    purity: '99%+',
    price: '£56.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769607.jpg?imageMogr2/format/webp',
    category: 'Blend',
    description: 'A synergistic peptide blend combining multiple growth factors for enhanced tissue regeneration research.',
    research: 'Used in comprehensive tissue regeneration and healing studies.'
  },
  {
    id: 20,
    name: 'CLOW',
    dosage: '80 mg',
    purity: '99%+',
    price: '£63.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769808.jpg?imageMogr2/format/webp',
    category: 'Blend',
    description: 'An advanced peptide blend formulated for comprehensive cellular optimization and metabolic support research.',
    research: 'Applied in metabolic support and cellular optimization studies.'
  },
  {
    id: 21,
    name: 'Melanotan II',
    dosage: '10 mg',
    purity: '99%+',
    price: '£12.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769809.jpg?imageMogr2/format/webp',
    category: 'Cosmetic',
    description: 'A synthetic melanocortin peptide studied for melanogenesis, skin pigmentation, and related dermatological research.',
    research: 'Used in studies on melanin production, skin pigmentation mechanisms, and UV protection research applications.'
  }
];

const trustBadges = [
  { icon: ShieldCheck, title: '99%+ Purity', desc: 'HPLC verified' },
  { icon: FlaskConical, title: 'Lab Tested', desc: 'Independent COAs' },
  { icon: Award, title: 'GMP Certified', desc: 'Pharma grade' },
  { icon: Truck, title: 'Fast Shipping', desc: '1-3 day delivery' },
  { icon: CreditCard, title: 'Secure Payment', desc: '256-bit SSL' },
  { icon: CheckCircle2, title: 'Discreet Packaging', desc: 'Plain unmarked' }
];

const testimonials = [
  {
    name: 'Dr. Sarah Mitchell',
    role: 'Research Scientist',
    content: 'Pro Health Peptides has been my go-to source for research materials. The quality is consistently excellent and their customer service is outstanding.',
    rating: 5
  },
  {
    name: 'Prof. James Chen',
    role: 'University Researcher',
    content: 'I have been using their peptides for metabolic studies for over 2 years. The purity reports are always accurate and shipping is lightning fast.',
    rating: 5
  },
  {
    name: 'Dr. Emma Williams',
    role: 'Lab Director',
    content: 'Finally a supplier I can trust. Their documentation is thorough and the products arrive exactly as described. Highly recommended.',
    rating: 5
  }
];

export default function Home() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [quickViewProduct, setQuickViewProduct] = useState<typeof products[0] | null>(null);
  const [clickedProductId, setClickedProductId] = useState<number | null>(null);

  // Get quantity for a product
  const getProductQuantity = (productId: number) => {
    const item = cart.find((item) => item.id === productId);
    return item ? item.quantity : 0;
  };

  // Featured products - static display (first 6 products)
  const featuredProducts = products.slice(0, 6);

  // Load cart from localStorage and listen for updates
  useEffect(() => {
    const savedCart = localStorage.getItem('php_cart');
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }

    const handleCartUpdate = () => {
      const updatedCart = localStorage.getItem('php_cart');
      if (updatedCart) {
        setCart(JSON.parse(updatedCart));
      }
    };

    window.addEventListener('cartUpdated', handleCartUpdate);
    return () => window.removeEventListener('cartUpdated', handleCartUpdate);
  }, []);



  const addToCart = (product: typeof products[0]) => {
    // Visual feedback - set clicked state
    setClickedProductId(product.id);
    setTimeout(() => setClickedProductId(null), 300);

    const cartData = JSON.parse(localStorage.getItem('php_cart') || '[]') as CartItem[];
    const existing = cartData.find((item: CartItem) => item.id === product.id);
    if (existing) {
      existing.quantity += 1;
    } else {
      cartData.push({ id: product.id, name: product.name, dosage: product.dosage, price: product.price, quantity: 1 });
    }
    localStorage.setItem('php_cart', JSON.stringify(cartData));
    window.dispatchEvent(new Event('cartUpdated'));
    setCart(cartData);
  };

  return (
    <div className="bg-gray-900 min-h-screen">
      {/* Quick View Modal */}
      {quickViewProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setQuickViewProduct(null)} />
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative bg-gray-900 border border-white/10 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
          >
            <button
              onClick={() => setQuickViewProduct(null)}
              className="absolute top-4 right-4 p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors z-10"
            >
              <X className="w-5 h-5 text-white" />
            </button>
            <div className="grid md:grid-cols-2 gap-6 p-6">
              <div className="aspect-square bg-gray-800 rounded-xl p-6 flex items-center justify-center">
                <img src={quickViewProduct.image} alt={quickViewProduct.name} className="max-h-full max-w-full object-contain" />
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-2 mb-2">
                  <span className="bg-blue-500/20 text-blue-400 text-xs font-semibold px-2 py-1 rounded-full">{quickViewProduct.category}</span>
                  <span className="bg-green-500/20 text-green-400 text-xs font-semibold px-2 py-1 rounded-full">{quickViewProduct.purity}</span>
                </div>
                <h2 className="text-2xl font-bold text-white mb-1">{quickViewProduct.name}</h2>
                <p className="text-gray-400 mb-4">{quickViewProduct.dosage}</p>
                <p className="text-3xl font-bold text-white mb-4">{quickViewProduct.price}</p>
                <p className="text-white text-sm mb-4">{quickViewProduct.description}</p>
                <p className="text-gray-500 text-xs mb-6">{quickViewProduct.research}</p>
                <div className="mt-auto flex gap-3">
                  <button
                    onClick={() => { addToCart(quickViewProduct); setQuickViewProduct(null); }}
                    className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-xl font-medium hover:from-blue-700 hover:to-purple-700 transition-all"
                  >
                    Add to Cart
                  </button>
                  <a
                    href="/products"
                    className="px-4 py-3 border border-white/20 text-white rounded-xl hover:bg-white/10 transition-colors"
                  >
                    View All
                  </a>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Hero Section - Dark Theme with Glow */}
      <section className="relative pt-24 pb-20 lg:pt-32 lg:pb-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-gray-900 to-purple-900/20" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={staggerContainer}
              className="space-y-8"
            >
              <motion.div variants={fadeIn} className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/30 text-blue-400 px-4 py-2 rounded-full text-sm font-medium backdrop-blur-sm">
                <CheckCircle2 className="w-4 h-4" />
                Independently Lab Tested
              </motion.div>
              
              <motion.h1 
                variants={fadeIn}
                className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight"
              >
                Premium Research Peptides for{' '}
                <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">Scientific Excellence</span>
              </motion.h1>
              
              <motion.p 
                variants={fadeIn}
                className="text-lg text-gray-400 leading-relaxed max-w-xl"
              >
                Laboratory-grade peptides with 99%+ purity, independently tested and verified. 
                Trusted by researchers worldwide for metabolic, healing, and longevity studies.
              </motion.p>
              
              <motion.div variants={fadeIn} className="flex flex-wrap gap-4">
                <a 
                  href="/products"
                  className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-xl font-medium hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg shadow-blue-500/25"
                >
                  View Catalog
                  <ArrowRight className="w-5 h-5" />
                </a>
                <a 
                  href="#about"
                  className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm text-white border border-white/20 px-8 py-4 rounded-xl font-medium hover:bg-white/20 transition-all"
                >
                  Learn More
                </a>
              </motion.div>
              
              <motion.div variants={fadeIn} className="flex items-center gap-6 pt-4">
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <ShieldCheck className="w-5 h-5 text-green-400" />
                  <span>99%+ Purity</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <FlaskConical className="w-5 h-5 text-blue-400" />
                  <span>Lab Tested</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Zap className="w-5 h-5 text-amber-400" />
                  <span>Fast Shipping</span>
                </div>
              </motion.div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-blue-500/20 aspect-[4/3] lg:aspect-auto lg:h-[500px] border border-white/10">
                <img
                  src="https://cdn.wegic.ai/assets/onepage/uploads/2031481443271393281/image/2026/03/11/01KKCY6Q79RZP0BPWKZ5E1WVMF.jpg?imageMogr2/format/webp"
                  alt="Laboratory research"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 lg:bottom-6 lg:left-6 lg:right-6">
                  <div className="bg-gray-900/80 backdrop-blur-sm border border-white/10 rounded-xl lg:rounded-2xl p-4 lg:p-5 shadow-xl">
                    <div className="flex items-center gap-2 lg:gap-3 mb-2 lg:mb-3">
                      <span className="bg-gradient-to-r from-blue-600 to-purple-600 text-white text-xs font-semibold px-2 lg:px-3 py-1 rounded-full">21+ Products</span>
                      <span className="text-gray-400 text-xs lg:text-sm">Research Grade</span>
                    </div>
                    <h3 className="font-bold text-white text-base lg:text-lg mb-1">Complete Peptide Catalog</h3>
                    <p className="text-xs lg:text-sm text-gray-400">TB-500, NAD+, KPV, MOTS-c & more</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Trust Badges Section */}
      <section className="py-12 bg-gray-800/50 border-y border-white/5">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {trustBadges.map((badge, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex flex-col items-center text-center p-4"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl flex items-center justify-center mb-3">
                  <badge.icon className="w-6 h-6 text-blue-400" />
                </div>
                <h3 className="text-white font-semibold text-sm">{badge.title}</h3>
                <p className="text-gray-500 text-xs">{badge.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-20">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8">
            <div>
              <p className="text-blue-400 font-medium mb-2">Our Products</p>
              <h2 className="text-3xl md:text-4xl font-bold text-white">Research-Grade Peptides</h2>
            </div>
            <a 
              href="/products"
              className="mt-4 md:mt-0 text-blue-400 font-medium flex items-center gap-2 hover:gap-3 transition-all"
            >
              View All Products <ArrowRight className="w-5 h-5" />
            </a>
          </div>

          {/* Featured Products - Static Display */}
          <div className="grid md:grid-cols-3 gap-6">
            {featuredProducts.map((product, index) => {
              const quantity = getProductQuantity(product.id);
              const isClicked = clickedProductId === product.id;
              return (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="group bg-gray-800/50 border border-white/10 rounded-2xl overflow-hidden hover:border-blue-500/30 transition-all flex flex-col"
                >
                  <div className="aspect-square bg-gray-800 p-6 relative cursor-pointer" onClick={() => setQuickViewProduct(product)}>
                    <img
                      src={product.image}
                      alt={`${product.name} ${product.dosage}`}
                      className="w-full h-full object-contain group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute top-4 right-4 bg-green-500/20 text-green-400 px-3 py-1 rounded-full text-xs font-medium">
                      {product.purity}
                    </div>
                    <div className="absolute top-4 left-4 bg-blue-500/20 text-blue-400 px-3 py-1 rounded-full text-xs font-medium">
                      {product.category}
                    </div>
                    {/* Quantity Badge */}
                    {quantity > 0 && (
                      <div className="absolute bottom-4 left-4 bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                        <ShoppingBag className="w-3 h-3" />
                        {quantity} in cart
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <span className="bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-medium">Quick View</span>
                    </div>
                  </div>
                  <div className="p-6 flex-1 flex flex-col">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-white">{product.name}</h3>
                      <span className="text-sm text-gray-400">{product.dosage}</span>
                    </div>
                    {product.description && (
                      <p className="text-sm text-white mb-2 line-clamp-2">
                        {product.description}
                      </p>
                    )}
                    <div className="mt-auto flex items-center justify-between">
                      <span className="text-xl font-bold text-white">{product.price}</span>
                      <button
                        onClick={() => addToCart(product)}
                        className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-150 flex items-center gap-2 ${
                          isClicked
                            ? 'bg-green-600 scale-95'
                            : quantity > 0
                            ? 'bg-gradient-to-r from-blue-700 to-purple-700 hover:from-blue-600 hover:to-purple-600'
                            : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700'
                        } text-white`}
                      >
                        {isClicked ? (
                          <>
                            <CheckCircle2 className="w-4 h-4" />
                            Added!
                          </>
                        ) : (
                          <>
                            <ShoppingBag className="w-4 h-4" />
                            {quantity > 0 ? `Add (${quantity})` : 'Add to Cart'}
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
          
          {/* View All Button */}
          <div className="text-center mt-10">
            <a 
              href="/products"
              className="inline-flex items-center gap-2 bg-white/10 text-white border border-white/20 px-8 py-4 rounded-xl font-medium hover:bg-white/20 transition-colors"
            >
              View All Products <ArrowRight className="w-5 h-5" />
            </a>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-800/30">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <p className="text-blue-400 font-medium mb-2">Testimonials</p>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">What Researchers Say</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">Trusted by scientists and researchers worldwide</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-gray-800/50 border border-white/10 rounded-2xl p-6"
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-amber-400 fill-amber-400" />
                  ))}
                </div>
                <Quote className="w-8 h-8 text-blue-500/30 mb-4" />
                <p className="text-gray-300 mb-6">{testimonial.content}</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="text-white font-semibold">{testimonial.name}</h4>
                    <p className="text-gray-500 text-sm">{testimonial.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section id="about" className="py-20">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white mb-4">Why Researchers Trust Us</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">Committed to quality, transparency, and supporting scientific advancement</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: Beaker, title: 'Laboratory Verified', desc: 'Every batch is independently tested by third-party laboratories with full COAs provided.' },
              { icon: ShieldCheck, title: 'Secure Shipping', desc: 'Discrete packaging with temperature-controlled options. Tracked delivery worldwide.' },
              { icon: Microscope, title: 'Research Support', desc: 'Detailed product information and dedicated support for your research needs.' }
            ].map((feature, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-gray-800/50 border border-white/10 rounded-2xl p-8 text-center hover:border-blue-500/30 transition-all"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <feature.icon className="w-8 h-8 text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
                <p className="text-gray-400">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 bg-gray-800/30">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-white mb-4">Frequently Asked Questions</h2>
              <p className="text-gray-400">Everything you need to know about our research peptides</p>
            </div>

            <div className="space-y-4">
              {[
                { q: 'Are your peptides suitable for human consumption?', a: 'No. All our products are sold strictly for research purposes only and are not intended for human consumption. They are intended for laboratory research use by qualified professionals.' },
                { q: 'How do you ensure product quality?', a: 'Every batch undergoes rigorous third-party testing using HPLC and mass spectrometry. We provide Certificates of Analysis (COAs) with every order showing purity levels of 99% or higher.' },
                { q: 'What is your shipping policy?', a: 'We offer fast, tracked shipping with discrete packaging. UK orders typically arrive within 1-3 business days. International shipping available to most countries.' },
                { q: 'How should I store the peptides?', a: 'Lyophilized peptides should be stored at -20°C (-4°F) for long-term stability. Once reconstituted, store at 2-8°C (36-46°F) and use within the timeframe specified in the product documentation.' }
              ].map((faq, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-gray-800/50 border border-white/10 rounded-xl p-6"
                >
                  <h3 className="font-semibold text-white mb-2">{faq.q}</h3>
                  <p className="text-gray-400">{faq.a}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="bg-gradient-to-br from-blue-600/20 to-purple-600/20 border border-white/10 rounded-3xl p-8 md:p-12">
              <div className="text-center mb-10">
                <h2 className="text-3xl font-bold text-white mb-4">Get In Touch</h2>
                <p className="text-gray-400">Questions about our products? We are here to help.</p>
              </div>

              <div className="grid md:grid-cols-3 gap-8 mb-10">
                <div className="flex items-center gap-4 justify-center">
                  <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                    <Mail className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Email</p>
                    <p className="text-white">info@prohealthpeptides.com</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 justify-center">
                  <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                    <Phone className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Phone</p>
                    <p className="text-white">+44 (0) 20 1234 5678</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 justify-center">
                  <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                    <ShieldCheck className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Support</p>
                    <p className="text-white">Mon-Fri 9am-5pm GMT</p>
                  </div>
                </div>
              </div>

              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <input 
                    type="text" 
                    placeholder="Your Name"
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-500 focus:border-blue-500 focus:outline-none transition-colors"
                  />
                  <input 
                    type="email" 
                    placeholder="Your Email"
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-500 focus:border-blue-500 focus:outline-none transition-colors"
                  />
                </div>
                <input 
                  type="text" 
                  placeholder="Subject"
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-500 focus:border-blue-500 focus:outline-none transition-colors"
                />
                <textarea 
                  rows={4}
                  placeholder="Your Message"
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-500 focus:border-blue-500 focus:outline-none transition-colors resize-none"
                />
                <button 
                  type="submit"
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 rounded-xl font-medium hover:from-blue-700 hover:to-purple-700 transition-all"
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-950 border-t border-white/10 py-16">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-lg">PH</span>
                </div>
                <span className="text-xl font-semibold text-white">Pro Health <span className="font-light">Peptides</span></span>
              </div>
              <p className="text-gray-400 text-sm mb-6">Premium research peptides for scientific excellence. Lab-tested, independently verified.</p>
              <div className="flex gap-4">
                {['VISA', 'Mastercard', 'PayPal'].map((method) => (
                  <div key={method} className="bg-white/10 px-3 py-1.5 rounded text-gray-400 text-xs">{method}</div>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Products</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="/products" className="hover:text-blue-400 transition-colors">All Peptides</a></li>
                <li><a href="/products" className="hover:text-blue-400 transition-colors">Metabolic</a></li>
                <li><a href="/products" className="hover:text-blue-400 transition-colors">Healing & Recovery</a></li>
                <li><a href="/products" className="hover:text-blue-400 transition-colors">Longevity</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#about" className="hover:text-blue-400 transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Quality Guarantee</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Shipping Info</a></li>
                <li><a href="#contact" className="hover:text-blue-400 transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-blue-400 transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Research Use Only</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-gray-500 text-sm">© 2024 Pro Health Peptides. All rights reserved.</p>
            <p className="text-gray-500 text-sm text-center md:text-right">
              <span className="text-amber-400">For research purposes only.</span> Not for human consumption.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}