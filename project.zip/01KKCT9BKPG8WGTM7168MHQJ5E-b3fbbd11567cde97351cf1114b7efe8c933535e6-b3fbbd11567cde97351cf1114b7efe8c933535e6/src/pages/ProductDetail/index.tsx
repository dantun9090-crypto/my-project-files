import { motion } from 'framer-motion';
import { ArrowLeft, CheckCircle2, ShieldCheck, Download, Beaker, Package, FlaskConical, FileText } from 'lucide-react';
import { Link, useParams, useNavigate } from 'react-router-dom';

// Product data
const products = [
  {
    id: 1,
    name: 'Retatrutide',
    dosage: '10 mg',
    purity: '99%+',
    price: '£57.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194662805.jpg?imageMogr2/format/webp',
    category: 'Metabolic',
    description: 'A triple hormone receptor agonist (GCGR, GIPR, GLP-1R) studied for metabolic research including glucose regulation and energy expenditure.',
    research: 'Used in studies examining metabolic pathways, glucose homeostasis, and body composition research.',
    casNumber: 'N/A',
    molecularWeight: 'N/A',
    formula: 'Peptide analog',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-RET-2024-001',
  },
  {
    id: 2,
    name: 'Retatrutide',
    dosage: '20 mg',
    purity: '99%+',
    price: '£94.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194662506.jpg?imageMogr2/format/webp',
    category: 'Metabolic',
    description: 'A triple hormone receptor agonist (GCGR, GIPR, GLP-1R) studied for metabolic research including glucose regulation and energy expenditure.',
    research: 'Used in studies examining metabolic pathways, glucose homeostasis, and body composition research.',
    casNumber: 'N/A',
    molecularWeight: 'N/A',
    formula: 'Peptide analog',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-RET-2024-002',
  },
  {
    id: 3,
    name: 'Tirzepatide',
    dosage: '10 mg',
    purity: '99%+',
    price: '£39.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194662810.jpg?imageMogr2/format/webp',
    category: 'Metabolic',
    description: 'A dual GIP/GLP-1 receptor agonist studied for metabolic research including insulin secretion and glucagon regulation.',
    research: 'Used in research investigating glucose control, metabolic function, and pancreatic beta cell studies.',
    casNumber: 'N/A',
    molecularWeight: 'N/A',
    formula: 'Peptide analog',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-TIR-2024-001',
  },
  {
    id: 4,
    name: 'Tirzepatide',
    dosage: '20 mg',
    purity: '99%+',
    price: '£69.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194663214.jpg?imageMogr2/format/webp',
    category: 'Metabolic',
    description: 'A dual GIP/GLP-1 receptor agonist studied for metabolic research including insulin secretion and glucagon regulation.',
    research: 'Used in research investigating glucose control, metabolic function, and pancreatic beta cell studies.',
    casNumber: 'N/A',
    molecularWeight: 'N/A',
    formula: 'Peptide analog',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-TIR-2024-002',
  },
  {
    id: 5,
    name: 'Tirzepatide',
    dosage: '30 mg',
    purity: '99%+',
    price: '£84.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194661704.jpg?imageMogr2/format/webp',
    category: 'Metabolic',
    description: 'A dual GIP/GLP-1 receptor agonist studied for metabolic research including insulin secretion and glucagon regulation.',
    research: 'Used in research investigating glucose control, metabolic function, and pancreatic beta cell studies.',
    casNumber: 'N/A',
    molecularWeight: 'N/A',
    formula: 'Peptide analog',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-TIR-2024-003',
  },
  {
    id: 6,
    name: 'Tirzepatide',
    dosage: '60 mg',
    purity: '99%+',
    price: '£119.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194662812.jpg?imageMogr2/format/webp',
    category: 'Metabolic',
    description: 'A dual GIP/GLP-1 receptor agonist studied for metabolic research including insulin secretion and glucagon regulation.',
    research: 'Used in research investigating glucose control, metabolic function, and pancreatic beta cell studies.',
    casNumber: 'N/A',
    molecularWeight: 'N/A',
    formula: 'Peptide analog',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-TIR-2024-004',
  },
  {
    id: 7,
    name: 'BPC-157',
    dosage: '10 mg',
    purity: '99%+',
    price: '£19.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194698301.jpg?imageMogr2/format/webp',
    category: 'Healing',
    description: 'A synthetic pentadecapeptide studied for tissue regeneration, wound healing, and musculoskeletal repair research.',
    research: 'Used in studies on tissue repair, wound healing, and regenerative medicine applications.',
    casNumber: '137525-51-0',
    molecularWeight: '1419.5 g/mol',
    formula: 'C62H98N16O22',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-BPC-2024-001',
  },
  {
    id: 8,
    name: 'TB-500',
    dosage: '10 mg',
    purity: '99%+',
    price: '£24.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194699407.jpg?imageMogr2/format/webp',
    category: 'Healing',
    description: 'A synthetic version of thymosin beta-4 studied for cellular migration, tissue repair, and regenerative medicine.',
    research: 'Used in research on cellular migration, tissue regeneration, and musculoskeletal repair.',
    casNumber: '885340-08-9',
    molecularWeight: 'N/A',
    formula: 'Peptide analog',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-TB-2024-001',
  },
  {
    id: 9,
    name: 'KPV',
    dosage: '10 mg',
    purity: '99%+',
    price: '£19.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194698906.jpg?imageMogr2/format/webp',
    category: 'Anti-Inflammatory',
    description: 'A tripeptide (Lysine-Proline-Valine) studied for its anti-inflammatory properties and immune modulation research.',
    research: 'Used in studies examining anti-inflammatory effects and immune system modulation.',
    casNumber: 'N/A',
    molecularWeight: 'N/A',
    formula: 'Tripeptide',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-KPV-2024-001',
  },
  {
    id: 10,
    name: 'MOTS-c',
    dosage: '10 mg',
    purity: '99%+',
    price: '£19.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194698807.jpg?imageMogr2/format/webp',
    category: 'Longevity',
    description: 'A mitochondrial-derived peptide studied for metabolic regulation, cellular energy production, and longevity research.',
    research: 'Used in studies on mitochondrial function, metabolic regulation, and aging research.',
    casNumber: 'N/A',
    molecularWeight: 'N/A',
    formula: 'Peptide analog',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-MOTS-2024-001',
  },
  {
    id: 11,
    name: 'PT-141',
    dosage: '10 mg',
    purity: '99%+',
    price: '£14.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194698306.jpg?imageMogr2/format/webp',
    category: 'Performance',
    description: 'A melanocortin receptor agonist studied for neurological and sexual dysfunction research applications.',
    research: 'Used in research examining neurological pathways and related physiological responses.',
    casNumber: '189691-06-3',
    molecularWeight: '1025.2 g/mol',
    formula: 'C50H68N14O10',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-PT-2024-001',
  },
  {
    id: 12,
    name: 'NAD+',
    dosage: '100 mg',
    purity: '99%+',
    price: '£20.00',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194699408.jpg?imageMogr2/format/webp',
    category: 'Longevity',
    description: 'Nicotinamide adenine dinucleotide studied for cellular energy metabolism, DNA repair, and sirtuin activation research.',
    research: 'Used in studies on cellular metabolism, mitochondrial function, aging mechanisms, and metabolic disorders.',
    casNumber: '53-84-9',
    molecularWeight: '663.4 g/mol',
    formula: 'C21H27N7O14P2',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-NAD-2024-001',
  },
  {
    id: 13,
    name: 'NAD+',
    dosage: '250 mg',
    purity: '99%+',
    price: '£28.00',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769303.jpg?imageMogr2/format/webp',
    category: 'Longevity',
    description: 'Nicotinamide adenine dinucleotide studied for cellular energy metabolism, DNA repair, and sirtuin activation research.',
    research: 'Used in studies on cellular metabolism, mitochondrial function, aging mechanisms, and metabolic disorders.',
    casNumber: '53-84-9',
    molecularWeight: '663.4 g/mol',
    formula: 'C21H27N7O14P2',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-NAD-2024-002',
  },
  {
    id: 14,
    name: 'NAD+',
    dosage: '500 mg',
    purity: '99%+',
    price: '£52.00',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769404.jpg?imageMogr2/format/webp',
    category: 'Longevity',
    description: 'Nicotinamide adenine dinucleotide studied for cellular energy metabolism, DNA repair, and sirtuin activation research.',
    research: 'Used in studies on cellular metabolism, mitochondrial function, aging mechanisms, and metabolic disorders.',
    casNumber: '53-84-9',
    molecularWeight: '663.4 g/mol',
    formula: 'C21H27N7O14P2',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-NAD-2024-003',
  },
  {
    id: 15,
    name: 'NAD+',
    dosage: '1000 mg',
    purity: '99%+',
    price: '£90.00',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769405.jpg?imageMogr2/format/webp',
    category: 'Longevity',
    description: 'Nicotinamide adenine dinucleotide studied for cellular energy metabolism, DNA repair, and sirtuin activation research.',
    research: 'Used in studies on cellular metabolism, mitochondrial function, aging mechanisms, and metabolic disorders.',
    casNumber: '53-84-9',
    molecularWeight: '663.4 g/mol',
    formula: 'C21H27N7O14P2',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-NAD-2024-004',
  },
  {
    id: 16,
    name: 'GHK-Cu',
    dosage: '50 mg',
    purity: '99%+',
    price: '£24.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194780018.jpg?imageMogr2/format/webp',
    category: 'Cosmetic',
    description: 'Copper peptide studied for skin regeneration, collagen production, and tissue repair in dermatological research.',
    research: 'Used in studies on skin regeneration, collagen synthesis, and wound healing applications.',
    casNumber: '89030-95-5',
    molecularWeight: '340.4 g/mol',
    formula: 'C14H24CuN6O4',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-GHK-2024-001',
  },
  {
    id: 17,
    name: 'GHK-Cu',
    dosage: '100 mg',
    purity: '99%+',
    price: '£34.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194770307.jpg?imageMogr2/format/webp',
    category: 'Cosmetic',
    description: 'Copper peptide studied for skin regeneration, collagen production, and tissue repair in dermatological research.',
    research: 'Used in studies on skin regeneration, collagen synthesis, and wound healing applications.',
    casNumber: '89030-95-5',
    molecularWeight: '340.4 g/mol',
    formula: 'C14H24CuN6O4',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-GHK-2024-002',
  },
  {
    id: 18,
    name: 'Bacteriostatic Water',
    dosage: '10 ml',
    purity: 'Sterile',
    price: '£6.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769606.jpg?imageMogr2/format/webp',
    category: 'Accessories',
    description: 'Sterile water containing 0.9% benzyl alcohol used for reconstituting lyophilized peptides in laboratory settings.',
    research: 'Essential reagent for peptide reconstitution and research preparation.',
    casNumber: '7732-18-5',
    molecularWeight: '18.02 g/mol',
    formula: 'H2O',
    storage: 'Store at room temperature',
    shelfLife: '24 months when sealed',
    solvent: 'Ready to use',
    coa: 'Available upon request',
    batchNumber: 'PH-BAC-2024-001',
  },
  {
    id: 19,
    name: 'GLOW',
    dosage: '70 mg',
    purity: '99%+',
    price: '£56.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769607.jpg?imageMogr2/format/webp',
    category: 'Blends',
    description: 'A synergistic peptide blend combining multiple growth factors for enhanced tissue regeneration research.',
    research: 'Used in studies examining synergistic effects of peptide combinations on tissue repair.',
    casNumber: 'N/A',
    molecularWeight: 'N/A',
    formula: 'Peptide blend',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-GLOW-2024-001',
  },
  {
    id: 20,
    name: 'CLOW',
    dosage: '80 mg',
    purity: '99%+',
    price: '£63.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769808.jpg?imageMogr2/format/webp',
    category: 'Blends',
    description: 'An advanced peptide blend formulated for comprehensive cellular optimization and metabolic support research.',
    research: 'Used in studies on cellular optimization and metabolic pathway enhancement.',
    casNumber: 'N/A',
    molecularWeight: 'N/A',
    formula: 'Peptide blend',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-CLOW-2024-001',
  },
  {
    id: 21,
    name: 'Melanotan II',
    dosage: '10 mg',
    purity: '99%+',
    price: '£12.99',
    image: 'https://cdn.wegic.ai/assets/onepage/agent/images/1773194769809.jpg?imageMogr2/format/webp',
    category: 'Cosmetic',
    description: 'A synthetic melanocortin peptide studied for melanogenesis, skin pigmentation, and related dermatological research.',
    research: 'Used in studies on melanin production, skin pigmentation mechanisms, and UV protection research applications.',
    casNumber: '121062-08-6',
    molecularWeight: '1024.2 g/mol',
    formula: 'C50H69N15O9',
    storage: 'Store at 2-8°C (36-46°F)',
    shelfLife: '24 months when stored properly',
    solvent: 'Sterile water or bacteriostatic water',
    coa: 'Available upon request',
    batchNumber: 'PH-MEL-2024-001',
  },
];

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const product = products.find(p => p.id === Number(id));

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-900 pt-24 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Product Not Found</h1>
          <Link to="/products" className="text-blue-600 hover:underline">Back to Products</Link>
        </div>
      </div>
    );
  }

  interface CartItem {
    id: number;
    name: string;
    dosage: string;
    price: string;
    quantity: number;
  }

  const addToCart = () => {
    const cart = JSON.parse(localStorage.getItem('php_cart') || '[]') as CartItem[];
    const existing = cart.find((item) => item.id === product.id);
    if (existing) {
      existing.quantity += 1;
    } else {
      cart.push({
        id: product.id,
        name: product.name,
        dosage: product.dosage,
        price: product.price,
        quantity: 1
      });
    }
    localStorage.setItem('php_cart', JSON.stringify(cart));
    window.dispatchEvent(new Event('cartUpdated'));
    alert(`${product.name} ${product.dosage} added to cart!`);
  };

  return (
    <div className="min-h-screen bg-gray-900 pt-24 pb-20">
      <div className="container mx-auto px-6">
        {/* Breadcrumb */}
        <div className="mb-8">
          <button
            onClick={() => navigate(-1)}
            className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Products
          </button>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Product Image */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-gray-800/50 backdrop-blur-sm border border-white/10 rounded-2xl p-8"
          >
            <div className="aspect-square relative">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-contain"
              />
              <div className="absolute top-0 right-0 bg-green-500/20 text-green-400 px-3 py-1 rounded-full text-sm font-medium border border-green-500/30">
                {product.purity} Purity
              </div>
            </div>
          </motion.div>

          {/* Product Info */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div>
              <span className="inline-block bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium mb-3">
                {product.category}
              </span>
              <h1 className="text-4xl font-bold text-white">{product.name}</h1>
              <p className="text-2xl text-gray-500 mt-2">{product.dosage}</p>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-3xl font-bold text-blue-600">{product.price}</span>
              <span className="text-gray-500">per vial</span>
            </div>

            <div className="flex gap-4">
              <button
                onClick={addToCart}
                className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 rounded-xl font-medium hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg"
              >
                Add to Cart
              </button>
              <Link
                to="#contact"
                className="px-6 py-4 border-2 border-white/20 text-white rounded-xl font-medium hover:border-white/40 transition-colors"
              >
                Request COA
              </Link>
            </div>

            <div className="bg-blue-50 rounded-xl p-6 border border-blue-100">
              <h3 className="font-semibold text-white mb-2 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-blue-600" />
                Research Applications
              </h3>
              <p className="text-gray-400">{product.research}</p>
            </div>

            <div className="bg-gray-800/30 border border-white/10 rounded-xl p-6">
              <h3 className="font-semibold text-white mb-2">Description</h3>
              <p className="text-white">{product.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-800/30 border border-white/10 rounded-lg p-4">
                <div className="flex items-center gap-2 text-gray-500 mb-1">
                  <Beaker className="w-4 h-4" />
                  CAS Number
                </div>
                <p className="font-medium text-white">{product.casNumber}</p>
              </div>
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-center gap-2 text-gray-500 mb-1">
                  <FlaskConical className="w-4 h-4" />
                  Molecular Weight
                </div>
                <p className="font-medium text-gray-900">{product.molecularWeight}</p>
              </div>
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-center gap-2 text-gray-500 mb-1">
                  <FileText className="w-4 h-4" />
                  Formula
                </div>
                <p className="font-medium text-gray-900">{product.formula}</p>
              </div>
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-center gap-2 text-gray-500 mb-1">
                  <Package className="w-4 h-4" />
                  Batch Number
                </div>
                <p className="font-medium text-gray-900">{product.batchNumber}</p>
              </div>
            </div>

            <div className="bg-amber-50 rounded-xl p-6 border border-amber-200">
              <h3 className="font-semibold text-amber-900 mb-2 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5" />
                Storage & Handling
              </h3>
              <p className="text-amber-800">{product.storage}</p>
              <p className="text-amber-700 mt-2">Shelf Life: {product.shelfLife}</p>
            </div>

            <div className="bg-gray-800/30 border border-white/10 rounded-xl p-6">
              <h3 className="font-semibold text-white mb-2">Reconstitution</h3>
              <p className="text-gray-400">Recommended Solvent: {product.solvent}</p>
            </div>

            <div className="flex items-center gap-4 p-4 bg-green-900/20 rounded-xl border border-green-500/30">
              <Download className="w-8 h-8 text-green-400" />
              <div className="flex-1">
                <p className="font-medium text-green-300">Certificate of Analysis</p>
                <p className="text-sm text-green-700">{product.coa}</p>
              </div>
              <Link
                to="#contact"
                className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors"
              >
                Request
              </Link>
            </div>

            <div className="bg-red-900/20 p-4 rounded-xl border border-red-500/30">
              <p className="text-red-300 text-sm font-medium">
                Disclaimer: This product is for research purposes only. Not for human consumption.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
