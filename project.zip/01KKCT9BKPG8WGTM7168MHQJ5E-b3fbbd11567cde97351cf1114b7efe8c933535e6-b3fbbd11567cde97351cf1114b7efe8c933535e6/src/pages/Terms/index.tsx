import { FileText, AlertTriangle, User, Package, Thermometer, Scale, Truck, RefreshCw, Shield, BookOpen, Gavel, Mail } from 'lucide-react';

export default function Terms() {
  return (
    <div className="min-h-screen bg-gray-900 pt-24 pb-20">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-500/20 mb-6">
            <FileText className="w-8 h-8 text-blue-400" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">Terms and Conditions</h1>
          <p className="text-gray-400">Last Updated: 11 March 2026</p>
        </div>

        {/* Intro */}
        <div className="max-w-4xl mx-auto mb-12">
          <div className="bg-gray-800/50 border border-white/10 rounded-2xl p-6 md:p-8">
            <p className="text-gray-300 leading-relaxed">
              These Terms and Conditions govern your use of the website{' '}
              <a href="https://www.prohealthpeptides.co.uk" className="text-blue-400 hover:text-blue-300 underline">
                www.prohealthpeptides.co.uk
              </a>{' '}
              and the purchase of products from ProHealth Peptides.
            </p>
            <p className="text-gray-300 leading-relaxed mt-4">
              By accessing this website or placing an order, you agree to comply with and be bound by the following 
              Terms and Conditions. If you do not agree with these terms, you should not use this website.
            </p>
          </div>
        </div>

        {/* Terms Content */}
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Section 1 */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-red-400" />
              </div>
              <h2 className="text-xl font-bold text-white">1. Research Use Only</h2>
            </div>
            <p className="text-gray-300 leading-relaxed mb-4">
              All products sold by ProHealth Peptides are supplied <strong className="text-white">strictly for laboratory research purposes only</strong>.
            </p>
            <p className="text-gray-400 mb-4">Products sold on this website:</p>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-start gap-2">
                <span className="text-red-400 mt-1">•</span>
                <span>Are <strong className="text-white">not intended for human consumption</strong></span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 mt-1">•</span>
                <span>Are <strong className="text-white">not intended for veterinary use</strong></span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 mt-1">•</span>
                <span>Are <strong className="text-white">not intended to diagnose, treat, cure, or prevent any disease</strong></span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 mt-1">•</span>
                <span>Are <strong className="text-white">not pharmaceutical drugs or dietary supplements</strong></span>
              </li>
            </ul>
            <p className="text-gray-300 leading-relaxed mt-4">
              By purchasing products from this website you confirm that the materials will be used{' '}
              <strong className="text-white">solely for legitimate laboratory research purposes</strong> by qualified individuals.
            </p>
          </section>

          {/* Section 2 */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center">
                <User className="w-5 h-5 text-blue-400" />
              </div>
              <h2 className="text-xl font-bold text-white">2. Buyer Qualifications</h2>
            </div>
            <p className="text-gray-400 mb-4">By placing an order with ProHealth Peptides, you confirm that:</p>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-start gap-2">
                <span className="text-blue-400 mt-1">•</span>
                <span>You are <strong className="text-white">at least 18 years of age</strong></span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-400 mt-1">•</span>
                <span>You are legally permitted to purchase laboratory research chemicals</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-400 mt-1">•</span>
                <span>You have appropriate training or knowledge in handling research materials</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-400 mt-1">•</span>
                <span>The products will only be used in a <strong className="text-white">laboratory research environment</strong></span>
              </li>
            </ul>
            <p className="text-gray-300 leading-relaxed mt-4">
              ProHealth Peptides reserves the right to refuse service or cancel orders if misuse is suspected.
            </p>
          </section>

          {/* Section 3 */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center">
                <Package className="w-5 h-5 text-purple-400" />
              </div>
              <h2 className="text-xl font-bold text-white">3. Product Information</h2>
            </div>
            <p className="text-gray-300 leading-relaxed mb-4">
              Product descriptions, technical data, and research references on this website are provided{' '}
              <strong className="text-white">for informational purposes only</strong>.
            </p>
            <p className="text-gray-400 mb-4">ProHealth Peptides does not guarantee:</p>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-start gap-2">
                <span className="text-purple-400 mt-1">•</span>
                <span>Completeness of scientific references</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-purple-400 mt-1">•</span>
                <span>Suitability for specific research experiments</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-purple-400 mt-1">•</span>
                <span>Regulatory status of compounds in all jurisdictions</span>
              </li>
            </ul>
            <p className="text-gray-300 leading-relaxed mt-4">
              Products are sold <strong className="text-white">as laboratory research materials only</strong>.
            </p>
          </section>

          {/* Section 4 - Storage */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center">
                <Thermometer className="w-5 h-5 text-cyan-400" />
              </div>
              <h2 className="text-xl font-bold text-white">4. Storage and Handling Requirements</h2>
            </div>
            <p className="text-gray-300 leading-relaxed mb-6">
              To preserve product stability and maintain research quality, peptides supplied by ProHealth Peptides 
              must be stored under controlled laboratory conditions.
            </p>

            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div className="bg-gray-900/50 rounded-xl p-5 border border-white/5">
                <h3 className="font-semibold text-white mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                  Storage Before Reconstitution
                </h3>
                <p className="text-gray-300 text-sm leading-relaxed mb-3">
                  Lyophilized peptides should be stored in a <strong className="text-cyan-400">refrigerated environment between 2°C and 8°C</strong>.
                </p>
                <p className="text-gray-400 text-sm mb-2">Vials should remain:</p>
                <ul className="text-gray-300 text-sm space-y-1">
                  <li>• Sealed in original packaging</li>
                  <li>• Protected from moisture and light</li>
                  <li>• Stored in a laboratory refrigerator</li>
                </ul>
              </div>

              <div className="bg-gray-900/50 rounded-xl p-5 border border-white/5">
                <h3 className="font-semibold text-white mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                  Storage After Reconstitution
                </h3>
                <p className="text-gray-300 text-sm leading-relaxed mb-3">
                  Once reconstituted, the solution should be stored at <strong className="text-cyan-400">2°C to 8°C</strong>.
                </p>
                <p className="text-gray-400 text-sm mb-2">The solution should:</p>
                <ul className="text-gray-300 text-sm space-y-1">
                  <li>• Remain sealed in a sterile vial</li>
                  <li>• Be protected from contamination</li>
                  <li>• Remain refrigerated at all times</li>
                </ul>
              </div>
            </div>

            <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4">
              <p className="text-red-400 text-sm font-medium">
                <AlertTriangle className="w-4 h-4 inline mr-2" />
                Failure to follow proper storage conditions may result in degradation of the compound and unreliable research results.
              </p>
            </div>
          </section>

          {/* Section 5 */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
                <Scale className="w-5 h-5 text-green-400" />
              </div>
              <h2 className="text-xl font-bold text-white">5. Compliance With Laws</h2>
            </div>
            <p className="text-gray-300 leading-relaxed">
              Customers are responsible for ensuring that the <strong className="text-white">purchase, possession, and use</strong> of 
              products from this website comply with all applicable <strong className="text-white">local, national, and international laws</strong>.
            </p>
            <p className="text-gray-300 leading-relaxed mt-4">
              ProHealth Peptides shall not be responsible for misuse of research chemicals in violation of applicable laws.
            </p>
          </section>

          {/* Section 6 */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-orange-500/20 flex items-center justify-center">
                <Package className="w-5 h-5 text-orange-400" />
              </div>
              <h2 className="text-xl font-bold text-white">6. Orders and Acceptance</h2>
            </div>
            <p className="text-gray-400 mb-4">ProHealth Peptides reserves the right to:</p>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-start gap-2">
                <span className="text-orange-400 mt-1">•</span>
                <span>Refuse any order</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-orange-400 mt-1">•</span>
                <span>Cancel orders at its discretion</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-orange-400 mt-1">•</span>
                <span>Limit purchase quantities</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-orange-400 mt-1">•</span>
                <span>Request additional verification before shipping</span>
              </li>
            </ul>
            <p className="text-gray-300 leading-relaxed mt-4">
              Orders suspected of misuse may be cancelled without notice.
            </p>
          </section>

          {/* Section 7 */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-yellow-500/20 flex items-center justify-center">
                <Scale className="w-5 h-5 text-yellow-400" />
              </div>
              <h2 className="text-xl font-bold text-white">7. Pricing and Payment</h2>
            </div>
            <p className="text-gray-300 leading-relaxed">
              All prices displayed on the website are subject to change without notice.
            </p>
            <p className="text-gray-300 leading-relaxed mt-4">
              Orders will only be processed once <strong className="text-white">full payment has been received</strong>. 
              Payments are processed through secure third-party payment providers.
            </p>
          </section>

          {/* Section 8 */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-indigo-500/20 flex items-center justify-center">
                <Truck className="w-5 h-5 text-indigo-400" />
              </div>
              <h2 className="text-xl font-bold text-white">8. Shipping and Delivery</h2>
            </div>
            <p className="text-gray-300 leading-relaxed">
              Orders are typically processed within <strong className="text-white">1–3 business days</strong>. 
              Delivery times depend on courier services and location.
            </p>
            <p className="text-gray-400 mt-4 mb-4">ProHealth Peptides is not responsible for delays caused by:</p>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-start gap-2">
                <span className="text-indigo-400 mt-1">•</span>
                <span>Courier services</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-400 mt-1">•</span>
                <span>Customs inspections</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-400 mt-1">•</span>
                <span>Incorrect shipping information provided by the customer</span>
              </li>
            </ul>
          </section>

          {/* Section 9 */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-teal-500/20 flex items-center justify-center">
                <RefreshCw className="w-5 h-5 text-teal-400" />
              </div>
              <h2 className="text-xl font-bold text-white">9. Returns and Refunds</h2>
            </div>
            <p className="text-gray-300 leading-relaxed mb-4">
              Due to the specialised nature of research chemicals, returns may only be accepted if:
            </p>
            <ul className="space-y-2 text-gray-300 mb-4">
              <li className="flex items-start gap-2">
                <span className="text-teal-400 mt-1">•</span>
                <span>The product was damaged during delivery</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-teal-400 mt-1">•</span>
                <span>The incorrect product was supplied</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-teal-400 mt-1">•</span>
                <span>The product is defective</span>
              </li>
            </ul>
            <p className="text-gray-300 leading-relaxed">
              Customers must notify us within <strong className="text-white">7 days of receiving the product</strong>.
            </p>
          </section>

          {/* Section 10 */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-rose-500/20 flex items-center justify-center">
                <Shield className="w-5 h-5 text-rose-400" />
              </div>
              <h2 className="text-xl font-bold text-white">10. Limitation of Liability</h2>
            </div>
            <p className="text-gray-300 leading-relaxed mb-4">
              To the fullest extent permitted by law, ProHealth Peptides shall not be liable for any damages arising from:
            </p>
            <ul className="space-y-2 text-gray-300 mb-4">
              <li className="flex items-start gap-2">
                <span className="text-rose-400 mt-1">•</span>
                <span>Improper handling of research chemicals</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-400 mt-1">•</span>
                <span>Misuse of products</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-400 mt-1">•</span>
                <span>Failure to follow storage or laboratory safety procedures</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-400 mt-1">•</span>
                <span>Use outside of intended research purposes</span>
              </li>
            </ul>
            <p className="text-gray-300 leading-relaxed">
              Customers assume <strong className="text-white">full responsibility and risk</strong> associated with the use of purchased materials.
            </p>
          </section>

          {/* Section 11 */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-violet-500/20 flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-violet-400" />
              </div>
              <h2 className="text-xl font-bold text-white">11. Intellectual Property</h2>
            </div>
            <p className="text-gray-300 leading-relaxed">
              All content on this website including text, graphics, logos, and product descriptions are the property 
              of ProHealth Peptides and may not be copied, reproduced, or distributed without permission.
            </p>
          </section>

          {/* Section 12 */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center">
                <RefreshCw className="w-5 h-5 text-amber-400" />
              </div>
              <h2 className="text-xl font-bold text-white">12. Changes to Terms</h2>
            </div>
            <p className="text-gray-300 leading-relaxed">
              ProHealth Peptides reserves the right to update or modify these Terms and Conditions at any time. 
              Changes will take effect immediately once published on this website.
            </p>
          </section>

          {/* Section 13 */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-sky-500/20 flex items-center justify-center">
                <Gavel className="w-5 h-5 text-sky-400" />
              </div>
              <h2 className="text-xl font-bold text-white">13. Governing Law</h2>
            </div>
            <p className="text-gray-300 leading-relaxed">
              These Terms and Conditions shall be governed by and interpreted in accordance with the laws of{' '}
              <strong className="text-white">England and Wales</strong>.
            </p>
            <p className="text-gray-300 leading-relaxed mt-4">
              Any disputes arising from the use of this website shall fall under the jurisdiction of the{' '}
              <strong className="text-white">courts of England and Wales</strong>.
            </p>
          </section>

          {/* Section 14 */}
          <section className="bg-gray-800/30 border border-white/10 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-pink-500/20 flex items-center justify-center">
                <Mail className="w-5 h-5 text-pink-400" />
              </div>
              <h2 className="text-xl font-bold text-white">14. Contact</h2>
            </div>
            <p className="text-gray-300 leading-relaxed">
              For questions regarding these Terms and Conditions, customers may contact ProHealth Peptides through the 
              contact page on{' '}
              <a href="https://www.prohealthpeptides.co.uk" className="text-blue-400 hover:text-blue-300 underline">
                www.prohealthpeptides.co.uk
              </a>.
            </p>
          </section>
        </div>

        {/* Footer Note */}
        <div className="max-w-4xl mx-auto mt-12 text-center">
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-6">
            <p className="text-blue-400 text-sm">
              By using this website and placing orders, you acknowledge that you have read, understood, and agree to be bound by these Terms and Conditions.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
