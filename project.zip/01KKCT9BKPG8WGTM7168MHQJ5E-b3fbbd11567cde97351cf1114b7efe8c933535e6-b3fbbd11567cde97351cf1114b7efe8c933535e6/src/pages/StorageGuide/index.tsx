import { Thermometer, Snowflake, Sun, FlaskConical, AlertTriangle, Lightbulb, Clock, Truck, Droplets, PackageCheck, FileCheck, ChevronRight } from 'lucide-react';

export default function StorageGuide() {
  return (
    <div className="min-h-screen bg-gray-900 pt-24 pb-20">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-500/20 mb-6">
            <FlaskConical className="w-8 h-8 text-green-400" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">Laboratory Storage & Handling Guide</h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Proper storage and handling procedures are essential for maintaining peptide stability, purity, and research reliability. Follow these guidelines to ensure optimal results.
          </p>
        </div>

        {/* Quick Reference Cards */}
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto mb-16">
          {/* Temperature */}
          <div className="bg-gray-800/50 border border-white/10 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center">
                <Thermometer className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <h3 className="text-white font-semibold">Temperature</h3>
                <p className="text-gray-400 text-sm">2-8°C Refrigerated</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm">
              Store all peptides at 2-8°C in a laboratory refrigerator, both before and after reconstitution.
            </p>
          </div>

          {/* Light Protection */}
          <div className="bg-gray-800/50 border border-white/10 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-amber-500/20 flex items-center justify-center">
                <Sun className="w-6 h-6 text-amber-400" />
              </div>
              <div>
                <h3 className="text-white font-semibold">Light Protection</h3>
                <p className="text-gray-400 text-sm">Keep in Original Vials</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm">
              Light-sensitive peptides must remain in amber or opaque vials. Never expose to direct sunlight.
            </p>
          </div>

          {/* Shelf Life */}
          <div className="bg-gray-800/50 border border-white/10 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                <Clock className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <h3 className="text-white font-semibold">Shelf Life</h3>
                <p className="text-gray-400 text-sm">Up to 2 Years</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm">
              Lyophilized peptides stored properly can remain stable for up to 24 months from manufacture date.
            </p>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Section 1: Before Reconstitution */}
          <section className="bg-gray-800/50 border border-white/10 rounded-2xl overflow-hidden">
            <div className="p-6 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                  <PackageCheck className="w-5 h-5 text-blue-400" />
                </div>
                <h2 className="text-xl font-semibold text-white">Storage Before Reconstitution</h2>
              </div>
            </div>
            <div className="p-6 space-y-6">
              <div>
                <h3 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Thermometer className="w-4 h-4 text-blue-400" />
                  Temperature Requirements
                </h3>
                <p className="text-gray-400 text-sm mb-4">
                  Lyophilized (freeze-dried) peptides should be stored in a <strong className="text-white">refrigerated environment between 2°C and 8°C</strong>. This temperature range maintains the structural integrity of the peptide chain and prevents degradation.
                </p>
                <div className="bg-gray-900/50 rounded-xl p-4 border border-white/5">
                  <ul className="space-y-2 text-sm text-gray-400">
                    <li className="flex items-start gap-2">
                      <ChevronRight className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                      Keep vials sealed in their original packaging
                    </li>
                    <li className="flex items-start gap-2">
                      <ChevronRight className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                      Store in a laboratory refrigerator (not a domestic fridge with food items)
                    </li>
                    <li className="flex items-start gap-2">
                      <ChevronRight className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                      Protect from moisture and light exposure
                    </li>
                    <li className="flex items-start gap-2">
                      <ChevronRight className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                      Avoid temperature fluctuations and freezing
                    </li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Snowflake className="w-4 h-4 text-cyan-400" />
                  Freezer Storage Option (-20°C)
                </h3>
                <p className="text-gray-400 text-sm mb-4">
                  For long-term storage exceeding 6 months, peptides may be stored in a <strong className="text-white">-20°C freezer</strong>. This can extend stability up to 24 months or longer for most compounds.
                </p>
                <div className="bg-cyan-500/10 rounded-xl p-4 border border-cyan-500/20">
                  <p className="text-cyan-400 text-sm">
                    <strong>Note:</strong> When removing from -20°C storage, allow the vial to reach room temperature before opening to prevent condensation (moisture introduction).
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Section 2: After Reconstitution */}
          <section className="bg-gray-800/50 border border-white/10 rounded-2xl overflow-hidden">
            <div className="p-6 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                  <Droplets className="w-5 h-5 text-green-400" />
                </div>
                <h2 className="text-xl font-semibold text-white">Storage After Reconstitution</h2>
              </div>
            </div>
            <div className="p-6 space-y-6">
              <div>
                <h3 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Thermometer className="w-4 h-4 text-green-400" />
                  Refrigerated Storage (2-8°C)
                </h3>
                <p className="text-gray-400 text-sm mb-4">
                  Once reconstituted with bacteriostatic water or sterile saline, the peptide solution must be stored at <strong className="text-white">2°C to 8°C</strong> in a laboratory refrigerator. Reconstituted peptides are more susceptible to degradation and require strict temperature control.
                </p>
                <div className="bg-gray-900/50 rounded-xl p-4 border border-white/5">
                  <ul className="space-y-2 text-sm text-gray-400">
                    <li className="flex items-start gap-2">
                      <ChevronRight className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                      Use sterile vials and maintain aseptic technique
                    </li>
                    <li className="flex items-start gap-2">
                      <ChevronRight className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                      Keep the solution sealed when not in use
                    </li>
                    <li className="flex items-start gap-2">
                      <ChevronRight className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                      Protect from contamination and temperature fluctuations
                    </li>
                    <li className="flex items-start gap-2">
                      <ChevronRight className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                      Label vials with reconstitution date
                    </li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-purple-400" />
                  Shelf Life After Reconstitution
                </h3>
                <p className="text-gray-400 text-sm mb-4">
                  Reconstituted peptides typically remain stable for <strong className="text-white">14-30 days</strong> when stored properly at 2-8°C. Stability varies by compound; consult product-specific documentation for exact timelines.
                </p>
                <div className="bg-amber-500/10 rounded-xl p-4 border border-amber-500/20">
                  <p className="text-amber-400 text-sm">
                    <strong>Important:</strong> Do not freeze reconstituted solutions. Freezing can cause peptide aggregation and loss of potency.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Section 3: Light-Sensitive Peptides */}
          <section className="bg-gray-800/50 border border-white/10 rounded-2xl overflow-hidden">
            <div className="p-6 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-500/20 flex items-center justify-center">
                  <Sun className="w-5 h-5 text-amber-400" />
                </div>
                <h2 className="text-xl font-semibold text-white">Light-Sensitive Peptides</h2>
              </div>
            </div>
            <div className="p-6 space-y-6">
              <p className="text-gray-400 text-sm">
                Certain peptides are sensitive to light exposure and can degrade when exposed to UV or visible light. These compounds require additional protection.
              </p>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-gray-900/50 rounded-xl p-4 border border-white/5">
                  <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    Light-Sensitive Compounds
                  </h4>
                  <ul className="space-y-1 text-sm text-gray-400">
                    <li>• GHK-Cu (Copper Peptide)</li>
                    <li>• Melanotan II</li>
                    <li>• PT-141</li>
                    <li>• Alpha-MSH analogues</li>
                  </ul>
                </div>
                <div className="bg-gray-900/50 rounded-xl p-4 border border-white/5">
                  <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                    <Lightbulb className="w-4 h-4 text-blue-400" />
                    Protection Measures
                  </h4>
                  <ul className="space-y-1 text-sm text-gray-400">
                    <li>• Store in amber or opaque vials</li>
                    <li>• Keep in original packaging</li>
                    <li>• Minimize light exposure during handling</li>
                    <li>• Work in dim lighting when possible</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Section 4: Transport & Delivery */}
          <section className="bg-gray-800/50 border border-white/10 rounded-2xl overflow-hidden">
            <div className="p-6 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                  <Truck className="w-5 h-5 text-purple-400" />
                </div>
                <h2 className="text-xl font-semibold text-white">Transport & Delivery Temperature</h2>
              </div>
            </div>
            <div className="p-6 space-y-6">
              <p className="text-gray-400 text-sm">
                All ProHealth Peptides orders are shipped with temperature-controlled packaging to maintain product integrity during transit.
              </p>

              <div className="bg-gray-900/50 rounded-xl p-4 border border-white/5">
                <ul className="space-y-2 text-sm text-gray-400">
                  <li className="flex items-start gap-2">
                    <ChevronRight className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
                    <span><strong className="text-white">Insulated packaging</strong> with ice packs maintains 2-8°C during UK domestic delivery (1-2 days)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <ChevronRight className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
                    <span><strong className="text-white">Lyophilized peptides</strong> are stable at ambient temperature for short periods (shipping duration)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <ChevronRight className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
                    <span>Upon receipt, <strong className="text-white">immediately refrigerate</strong> products at 2-8°C</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <ChevronRight className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
                    <span>Contact us immediately if packaging arrives damaged or warm</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          {/* Section 5: Best Practices */}
          <section className="bg-gray-800/50 border border-white/10 rounded-2xl overflow-hidden">
            <div className="p-6 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                  <FileCheck className="w-5 h-5 text-green-400" />
                </div>
                <h2 className="text-xl font-semibold text-white">Laboratory Best Practices</h2>
              </div>
            </div>
            <div className="p-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-white font-medium mb-3">Handling Procedures</h4>
                  <ul className="space-y-2 text-sm text-gray-400">
                    <li className="flex items-start gap-2">
                      <span className="text-green-400">✓</span>
                      Use sterile technique when handling vials
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-400">✓</span>
                      Allow frozen vials to reach room temperature before opening
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-400">✓</span>
                      Use appropriate solvents (sterile water, BAC water)
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-400">✓</span>
                      Gently swirl to dissolve; do not shake vigorously
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-white font-medium mb-3">Documentation</h4>
                  <ul className="space-y-2 text-sm text-gray-400">
                    <li className="flex items-start gap-2">
                      <span className="text-green-400">✓</span>
                      Record lot numbers and expiry dates
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-400">✓</span>
                      Note reconstitution dates on vials
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-400">✓</span>
                      Keep Certificates of Analysis (COA) on file
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-400">✓</span>
                      Maintain laboratory storage temperature logs
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Section 6: Warning */}
          <section className="bg-red-500/10 border border-red-500/20 rounded-2xl p-6">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-red-500/20 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <h3 className="text-white font-semibold mb-2">Important Notice</h3>
                <p className="text-gray-400 text-sm">
                  Failure to follow proper storage conditions may result in <strong className="text-white">degradation of the compound</strong> and <strong className="text-white">unreliable research results</strong>. ProHealth Peptides guarantees product quality at the time of shipment; improper storage after delivery voids any quality guarantees. For questions about specific storage requirements, contact our technical support team.
                </p>
              </div>
            </div>
          </section>
        </div>

        {/* Contact CTA */}
        <div className="max-w-4xl mx-auto mt-12">
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-6 text-center">
            <p className="text-gray-400 text-sm mb-4">
              Have questions about peptide storage or handling?
            </p>
            <a 
              href="/#contact" 
              className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-medium transition-colors"
            >
              Contact Technical Support
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
