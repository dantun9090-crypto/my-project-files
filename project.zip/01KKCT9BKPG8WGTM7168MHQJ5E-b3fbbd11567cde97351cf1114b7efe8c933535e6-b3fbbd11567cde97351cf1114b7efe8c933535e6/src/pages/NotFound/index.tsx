import { Link } from 'react-router-dom';

export default function NotFoundPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#0A0A0A]">
      <div className="text-center space-y-6">
        <h1 className="text-6xl font-serif text-[#d4af37] tracking-widest font-light">404</h1>
        <p className="text-xl text-white uppercase tracking-widest text-sm">Sequence Not Found</p>
        <p className="text-sm text-zinc-500 max-w-md mx-auto font-light">
          The research protocol you are looking for does not exist or has been moved.
        </p>
        <Link
          to="/"
          className="inline-block border border-[#d4af37] text-[#d4af37] px-8 py-4 uppercase tracking-widest text-xs font-bold hover:bg-[#d4af37] hover:text-[#0A0A0A] transition-all mt-8"
        >
          Return to Lab
        </Link>
      </div>
    </div>
  );
}
