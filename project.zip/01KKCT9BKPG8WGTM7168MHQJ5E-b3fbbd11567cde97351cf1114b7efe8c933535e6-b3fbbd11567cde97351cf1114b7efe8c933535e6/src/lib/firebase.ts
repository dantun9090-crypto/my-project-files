// Firebase Configuration
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { getFirestore, doc, setDoc, getDoc, collection, addDoc, query, where, getDocs, orderBy, Timestamp, deleteDoc, updateDoc } from 'firebase/firestore';

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB5sWYCTkzeFFup0mqyg3PzCIzjP2oGJdM",
  authDomain: "prohealthpeptides-a0808.firebaseapp.com",
  projectId: "prohealthpeptides-a0808",
  storageBucket: "prohealthpeptides-a0808.firebasestorage.app",
  messagingSenderId: "1070409753291",
  appId: "1:1070409753291:web:8bf1e58130fbe23e66f14e",
  measurementId: "G-L8X0591XKB"
};

// Initialize Firebase (prevent duplicate initialization)
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app);

// ==================== TYPES ====================

export interface User {
  uid: string;
  email: string;
  createdAt: Timestamp;
  displayName?: string;
  shippingAddress?: string;
  billingAddress?: string;
}

export interface Product {
  id?: string;
  name: string;
  price: number;
  stock: number;
  createdAt: Timestamp;
  description?: string;
  imageUrl?: string;
  category?: string;
}

export interface Cart {
  id?: string;
  userId: string;
  createdAt: Timestamp;
  updatedAt?: Timestamp;
}

export interface CartItemDB {
  id?: string;
  cartId: string;
  productId: string;
  product?: Product;
  quantity: number;
}

export interface Order {
  id?: string;
  userId: string;
  orderDate: Timestamp;
  totalAmount: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  shippingAddress?: string;
  billingAddress?: string;
  createdAt: Timestamp;
}

export interface OrderItem {
  id?: string;
  orderId: string;
  productId: string;
  product?: Product;
  quantity: number;
  priceAtPurchase: number;
}

// ==================== AUTH FUNCTIONS ====================

export const registerUser = async (email: string, password: string, firstName: string, lastName: string) => {
  const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  const user = userCredential.user;
  
  // Create user document in Firestore
  const userData: Omit<User, 'uid'> = {
    email: user.email || email,
    displayName: `${firstName} ${lastName}`,
    createdAt: Timestamp.now(),
  };
  
  await setDoc(doc(db, 'users', user.uid), userData);
  
  return user;
};

export const loginUser = async (email: string, password: string) => {
  const userCredential = await signInWithEmailAndPassword(auth, email, password);
  return userCredential.user;
};

export const logoutUser = async () => {
  await signOut(auth);
};

export const getCurrentUser = (): Promise<FirebaseUser | null> => {
  return new Promise((resolve) => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      unsubscribe();
      resolve(user);
    });
  });
};

// ==================== USER FUNCTIONS ====================

export const getUserProfile = async (userId: string): Promise<User | null> => {
  const docRef = doc(db, 'users', userId);
  const docSnap = await getDoc(docRef);
  if (docSnap.exists()) {
    return { uid: docSnap.id, ...docSnap.data() } as User;
  }
  return null;
};

export const updateUserProfile = async (userId: string, data: Partial<User>) => {
  const userRef = doc(db, 'users', userId);
  await updateDoc(userRef, data);
};

// ==================== PRODUCT FUNCTIONS ====================

export const createProduct = async (product: Omit<Product, 'id' | 'createdAt'>) => {
  const productData = {
    ...product,
    createdAt: Timestamp.now(),
  };
  const docRef = await addDoc(collection(db, 'products'), productData);
  return docRef.id;
};

export const getProduct = async (productId: string): Promise<Product | null> => {
  const docRef = doc(db, 'products', productId);
  const docSnap = await getDoc(docRef);
  if (docSnap.exists()) {
    return { id: docSnap.id, ...docSnap.data() } as Product;
  }
  return null;
};

export const getAllProducts = async (): Promise<Product[]> => {
  const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as Product);
};

export const getProductsByCategory = async (category: string): Promise<Product[]> => {
  const q = query(
    collection(db, 'products'),
    where('category', '==', category),
    orderBy('createdAt', 'desc')
  );
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as Product);
};

export const updateProduct = async (productId: string, data: Partial<Product>) => {
  const productRef = doc(db, 'products', productId);
  await updateDoc(productRef, data);
};

export const deleteProduct = async (productId: string) => {
  await deleteDoc(doc(db, 'products', productId));
};

// ==================== CART FUNCTIONS ====================

export const getOrCreateCart = async (userId: string): Promise<Cart> => {
  // Check if user already has a cart
  const q = query(collection(db, 'carts'), where('userId', '==', userId));
  const querySnapshot = await getDocs(q);
  
  if (!querySnapshot.empty) {
    const cartDoc = querySnapshot.docs[0];
    return { id: cartDoc.id, ...cartDoc.data() } as Cart;
  }
  
  // Create new cart
  const cartData = {
    userId,
    createdAt: Timestamp.now(),
  };
  const docRef = await addDoc(collection(db, 'carts'), cartData);
  return { id: docRef.id, ...cartData } as Cart;
};

export const getCartItems = async (cartId: string): Promise<CartItemDB[]> => {
  const q = query(collection(db, 'cartItems'), where('cartId', '==', cartId));
  const querySnapshot = await getDocs(q);
  
  const items: CartItemDB[] = [];
  for (const docSnap of querySnapshot.docs) {
    const item = { id: docSnap.id, ...docSnap.data() } as CartItemDB;
    // Fetch product details
    if (item.productId) {
      const product = await getProduct(item.productId);
      if (product) {
        item.product = product;
      }
    }
    items.push(item);
  }
  return items;
};

export const addToCart = async (cartId: string, productId: string, quantity: number) => {
  // Check if product already in cart
  const q = query(
    collection(db, 'cartItems'),
    where('cartId', '==', cartId),
    where('productId', '==', productId)
  );
  const querySnapshot = await getDocs(q);
  
  if (!querySnapshot.empty) {
    // Update quantity
    const itemDoc = querySnapshot.docs[0];
    const currentQty = itemDoc.data().quantity;
    await updateDoc(doc(db, 'cartItems', itemDoc.id), {
      quantity: currentQty + quantity
    });
    return itemDoc.id;
  } else {
    // Add new item
    const itemData = {
      cartId,
      productId,
      quantity,
    };
    const docRef = await addDoc(collection(db, 'cartItems'), itemData);
    return docRef.id;
  }
};

export const updateCartItemQuantity = async (itemId: string, quantity: number) => {
  if (quantity <= 0) {
    await deleteDoc(doc(db, 'cartItems', itemId));
  } else {
    await updateDoc(doc(db, 'cartItems', itemId), { quantity });
  }
};

export const removeFromCart = async (itemId: string) => {
  await deleteDoc(doc(db, 'cartItems', itemId));
};

export const clearCart = async (cartId: string) => {
  const q = query(collection(db, 'cartItems'), where('cartId', '==', cartId));
  const querySnapshot = await getDocs(q);
  
  const deletePromises = querySnapshot.docs.map(docSnap => 
    deleteDoc(doc(db, 'cartItems', docSnap.id))
  );
  await Promise.all(deletePromises);
  
  // Update cart timestamp
  await updateDoc(doc(db, 'carts', cartId), {
    updatedAt: Timestamp.now()
  });
};

// ==================== ORDER FUNCTIONS ====================

export const createOrder = async (
  userId: string,
  items: { productId: string; quantity: number; priceAtPurchase: number }[],
  shippingAddress?: string,
  billingAddress?: string
): Promise<string> => {
  // Calculate total
  const totalAmount = items.reduce((sum, item) => 
    sum + (item.priceAtPurchase * item.quantity), 0
  );
  
  // Create order
  const orderData = {
    userId,
    orderDate: Timestamp.now(),
    totalAmount,
    status: 'pending' as const,
    shippingAddress,
    billingAddress,
    createdAt: Timestamp.now(),
  };
  
  const orderRef = await addDoc(collection(db, 'orders'), orderData);
  
  // Create order items
  const orderItemPromises = items.map(item => 
    addDoc(collection(db, 'orderItems'), {
      orderId: orderRef.id,
      productId: item.productId,
      quantity: item.quantity,
      priceAtPurchase: item.priceAtPurchase,
    })
  );
  await Promise.all(orderItemPromises);
  
  return orderRef.id;
};

export const getOrder = async (orderId: string): Promise<{ order: Order; items: OrderItem[] } | null> => {
  const orderRef = doc(db, 'orders', orderId);
  const orderSnap = await getDoc(orderRef);
  
  if (!orderSnap.exists()) return null;
  
  const order = { id: orderSnap.id, ...orderSnap.data() } as Order;
  
  // Get order items
  const q = query(collection(db, 'orderItems'), where('orderId', '==', orderId));
  const itemsSnapshot = await getDocs(q);
  
  const items: OrderItem[] = [];
  for (const docSnap of itemsSnapshot.docs) {
    const item = { id: docSnap.id, ...docSnap.data() } as OrderItem;
    if (item.productId) {
      const product = await getProduct(item.productId);
      if (product) {
        item.product = product;
      }
    }
    items.push(item);
  }
  
  return { order, items };
};

export const getUserOrders = async (userId: string): Promise<Order[]> => {
  const q = query(
    collection(db, 'orders'),
    where('userId', '==', userId),
    orderBy('orderDate', 'desc')
  );
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as Order);
};

export const getAllOrders = async (): Promise<Order[]> => {
  const q = query(collection(db, 'orders'), orderBy('orderDate', 'desc'));
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as Order);
};

export const updateOrderStatus = async (orderId: string, status: Order['status']) => {
  const orderRef = doc(db, 'orders', orderId);
  await updateDoc(orderRef, { status });
};

// Legacy function for backwards compatibility
export const saveOrder = async (userId: string, orderData: any) => {
  return createOrder(
    userId,
    orderData.items || [],
    orderData.shippingAddress,
    orderData.billingAddress
  );
};

export { Timestamp };
