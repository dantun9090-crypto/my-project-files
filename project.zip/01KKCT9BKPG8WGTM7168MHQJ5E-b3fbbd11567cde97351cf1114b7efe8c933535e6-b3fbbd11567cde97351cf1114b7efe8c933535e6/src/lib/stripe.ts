// Stripe Configuration
// Using publishable key for client-side integration

export const stripeConfig = {
  publishableKey: 'pk_test_51T9sOaELOHTaocHhIjtaljzhs4p51raRWvoRpIU7Hw2oTjTSUChmzkisZapP68Z6FzcfkAFeefAn9jghko5CSWFk00KlWATlDC',
};

// For static sites, we use Stripe Payment Links or redirect to Stripe Checkout
// You need to create products in Stripe Dashboard and get your payment links

export const getStripeCheckoutUrl = (amount: number, description: string) => {
  // Option 1: Using Stripe Payment Link (Recommended for static sites)
  // Replace with your actual Stripe Payment Link
  // Create at: https://dashboard.stripe.com/payment-links
  
  // Option 2: Using Stripe Checkout Session (requires backend)
  // For now, we'll redirect to Stripe's hosted checkout
  
  // For testing, you can use a simple payment link
  // In production, you should use proper Stripe Checkout with a backend
  
  return `https://checkout.stripe.com/pay?client_reference_id=${encodeURIComponent(description)}&amount=${amount * 100}`;
};

// Product price IDs from Stripe Dashboard
// Create products at: https://dashboard.stripe.com/products
export const stripePriceIds: Record<string, string> = {
  // Add your product price IDs here after creating them in Stripe
  // Example: 'retatrutide-5mg': 'price_1234567890',
};
