# Firebase Setup Guide

Your website now has **real Firebase integration** for customer accounts and order management!

## What You Get

✅ **Real Customer Authentication** - Email/password login with Firebase Auth  
✅ **Cloud Database** - Orders stored permanently in Firestore  
✅ **Account Page** - Customers can view their order history  
✅ **Secure** - Firebase handles all security and encryption  

---

## Step 1: Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click **"Create a project"**
3. Name it: `prohealthpeptides` (or your preferred name)
4. Disable Google Analytics (optional)
5. Click **"Create project"**

---

## Step 2: Enable Authentication

1. In Firebase Console, click **"Authentication"** in the left menu
2. Click **"Get started"**
3. Click **"Email/Password"**
4. Toggle **"Enable"** to ON
5. Click **"Save"**

---

## Step 3: Enable Firestore Database

1. Click **"Firestore Database"** in the left menu
2. Click **"Create database"**
3. Choose **"Start in production mode"**
4. Select your region (europe-west for UK)
5. Click **"Enable"**

---

## Step 4: Get Your Config

1. Click the **gear icon** (⚙️) next to "Project Overview"
2. Click **"Project settings"**
3. Scroll down to **"Your apps"** section
4. Click the **"</>"** icon (Web)
5. Register app name: `prohealthpeptides-website`
6. Click **"Register app"**
7. **Copy the firebaseConfig object** - it looks like this:

```javascript
const firebaseConfig = {
  apiKey: "AIza...",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};
```

---

## Step 5: Update Your Website

1. Open `src/lib/firebase.ts` in your code
2. Replace the placeholder values with your actual config:

```typescript
const firebaseConfig = {
  apiKey: "YOUR_ACTUAL_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

3. Save the file
4. Rebuild: `pnpm run build`
5. Upload new `dist` folder to Hostinger

---

## Testing

1. Visit your website
2. Add items to cart
3. Checkout with **"Create Account"** checked
4. Enter email/password
5. Complete order
6. Go to **My Account** page - you should see:
   - Your profile
   - Order history
   - Order details

---

## Free Tier Limits (Firebase Spark Plan)

- **Authentication**: 50,000 users/month FREE
- **Firestore**: 50,000 reads/day, 20,000 writes/day FREE
- Perfect for small-medium stores!

---

## Troubleshooting

**"Firebase App named '[DEFAULT]' already exists"**
- This is normal, just refresh the page

**"Permission denied" errors**
- Check Firestore rules in Firebase Console
- Default rules should allow authenticated users

**Orders not showing in account**
- Make sure customer created account during checkout
- Orders are linked to user accounts only

---

## Next Steps

You now have a fully functional e-commerce site with:
- ✅ Real customer accounts
- ✅ Permanent order storage
- ✅ Order history
- ✅ Cloud database

Want to add more features?
- Email order confirmations
- Admin dashboard
- Inventory management
- Customer messaging

Let me know if you need help!
